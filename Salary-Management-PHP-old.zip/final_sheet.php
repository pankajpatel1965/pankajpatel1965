<?php
ob_start();
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

require __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Font;

$company = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM company_details LIMIT 1"));

$month_year = isset($_POST['month_year']) ? $_POST['month_year'] : '';
$filter_type = isset($_POST['filter_type']) ? $_POST['filter_type'] : '';
$search = isset($_POST['search']) ? $_POST['search'] : '';
$sort_order = isset($_POST['sort_order']) ? $_POST['sort_order'] : 'desc';

// Convert month_year to formatted month name (e.g., "June-2025")
$formatted_month_year = '';
if ($month_year) {
    $dateObj = DateTime::createFromFormat('Y-m', $month_year);
    if ($dateObj) {
        $formatted_month_year = $dateObj->format('F-Y');
    }
}

// Define filter type display name
$filter_display_name = '';
switch ($filter_type) {
    case 'cash':
        $filter_display_name = 'Cash';
        break;
    case 'hdfc':
        $filter_display_name = 'HDFC Bank';
        break;
    case 'other':
        $filter_display_name = 'Other Banks';
        break;
    case 'apprentice':
        $filter_display_name = 'Apprentice';
        break;
    case 'pf':
        $filter_display_name = 'Provident Fund';
        break;
    case 'pt':
        $filter_display_name = 'Professional Tax';
        break;
    default:
        $filter_display_name = 'All';
}

$month_filter_display = $formatted_month_year ? "$filter_display_name $formatted_month_year" : $filter_display_name;

$query = "SELECT e.id, e.name, e.email, e.payment_type, e.bank_name, e.micr_code, e.ifsc_code, e.account_number, 
          s.month_year, s.value_date, s.total_salary, s.extra_days, s.extra, s.bonus, s.leave_full_days, s.leave_half_days, 
          s.deduct_pf, s.pf, s.professional_tax, s.late_charge, s.deposit, s.withdrawal, s.uniform, s.net_pay 
          FROM employees e 
          JOIN salaries s ON e.id = s.employee_id";

$conditions = [];
$params = [];
$types = "";
if ($month_year) {
    $conditions[] = "s.month_year = ?";
    $params[] = $month_year;
    $types .= "s";
}
if ($filter_type) {
    if ($filter_type === 'cash') {
        $conditions[] = "e.payment_type = ?";
        $params[] = 'cash';
        $types .= "s";
    } elseif ($filter_type === 'hdfc') {
        $conditions[] = "e.payment_type = ? AND e.bank_name = ?";
        $params[] = 'bank';
        $params[] = 'HDFC';
        $types .= "ss";
    } elseif ($filter_type === 'other') {
        $conditions[] = "e.payment_type = ? AND e.bank_name = ?";
        $params[] = 'bank';
        $params[] = 'Other';
        $types .= "ss";
    } elseif ($filter_type === 'apprentice') {
        $conditions[] = "e.payment_type = ? AND e.bank_name = ?";
        $params[] = 'bank';
        $params[] = 'Apprentice';
        $types .= "ss";
    } elseif ($filter_type === 'pf') {
        $conditions[] = "s.deduct_pf = ?";
        $params[] = 1;
        $types .= "i";
    } elseif ($filter_type === 'pt') {
        $conditions[] = "s.professional_tax > 0";
    }
}
if ($search) {
    $conditions[] = "e.name LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " ORDER BY s.net_pay " . ($sort_order === 'asc' ? 'ASC' : 'DESC');

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$excel_data = [];
$pf_excel_data = [];
$pt_excel_data = [];
$total_amount = 0;
$total_net_pay = 0;
$total_basic_salary = 0;
$total_extra = 0;
$total_extra_days_salary = 0;
$total_bonus = 0;
$total_leave_deduction = 0;
$total_pf = 0;
$total_pt = 0;
$sr = 1;
$data_rows = [];
while ($row = $result->fetch_assoc()) {
    $basic_salary = round($row['total_salary']);
    $daily_rate = $basic_salary / 30;
    $extra_days = $row['extra_days'] ?? 0;
    $extra = round($row['extra'] ?? 0);
    $bonus = round($row['bonus'] ?? 0);
    $leave_full_days = $row['leave_full_days'] ?? 0;
    $leave_half_days = $row['leave_half_days'] ?? 0;
    $late_charge = round($row['late_charge'] ?? 0);
    $deposit = round($row['deposit'] ?? 0);
    $withdrawal = round($row['withdrawal'] ?? 0);
    $uniform = round($row['uniform'] ?? 0);
    $net_pay = round($row['net_pay']);
    $pf = round($row['pf'] ?? 0);
    $professional_tax = round($row['professional_tax'] ?? 0);

    $extra_days_salary = round($daily_rate * $extra_days);
    $leave_deduction = round(($leave_full_days + $leave_half_days * 0.5) * $daily_rate);
    $value_date = $row['value_date'] ? (new DateTime($row['value_date']))->format('d/m/Y') : '-';

    if ($filter_type === 'cash') {
        $data_row = [
            'Srno' => $sr,
            'Employee Name' => $row['name'],
            'Net Salary' => $net_pay
        ];
    } elseif ($filter_type === 'hdfc') {
        $data_row = [
            'Srno' => $sr,
            'Employee Name' => $row['name'],
            'Net Salary' => $net_pay,
            'MICR Code' => $row['micr_code'] ?: '-',
            'IFSC Code' => $row['ifsc_code'] ?: '-',
            'Beneficiary Account No.' => $row['account_number'] . "\t" ?: '-'
        ];
    } elseif ($filter_type === 'other') {
        $data_row = [
            'Srno' => $sr,
            'Employee Name' => $row['name'],
            'Net Salary' => $net_pay,
            'MICR Code' => $row['micr_code'] ?: '-',
            'IFSC Code' => $row['ifsc_code'] ?: '-',
            'Beneficiary Account No.' => $row['account_number'] . "\t" ?: '-'
        ];
    } elseif ($filter_type === 'pf') {
        $data_row = [
            'Srno' => $sr,
            'Name' => $row['name'],
            'Basic Salary' => $basic_salary,
            'Extra' => $extra,
            'Extra Days Salary (₹)' => $extra_days_salary,
            'Bonus' => $bonus,
            'Leave Deduction' => $leave_deduction,
            'Gross Salary' => $basic_salary + $extra + $extra_days_salary + $bonus - $leave_deduction,
            'Less: Provident Fund' => $pf
        ];
    } elseif ($filter_type === 'pt') {
        $data_row = [
            'Srno' => $sr,
            'Name' => $row['name'],
            'Professional Tax' => $professional_tax
        ];
    } else {
        $data_row = [
            'Srno' => $sr,
            'Employee Name' => $row['name'],
            'Net Salary' => $net_pay,
            'MICR Code' => $row['micr_code'] ?: '-',
            'IFSC Code' => $row['ifsc_code'] ?: '-',
            'Beneficiary Account No.' => $row['account_number'] . "\t" ?: '-'
        ];
    }

    $data_rows[] = $data_row;

    if ($row['deduct_pf']) {
        $pf_excel_data[] = [
            'Srno' => $sr,
            'Name' => $row['name'],
            'Basic Salary' => $basic_salary,
            'Extra' => $extra,
            'Extra Days Salary (₹)' => $extra_days_salary,
            'Bonus' => $bonus,
            'Leave Deduction' => $leave_deduction,
            'Gross Salary' => $basic_salary + $extra + $extra_days_salary + $bonus - $leave_deduction,
            'Less: Provident Fund' => $pf
        ];
        $total_pf += $pf;
    }

    if ($row['professional_tax'] > 0) {
        $pt_excel_data[] = [
            'Srno' => $sr,
            'Name' => $row['name'],
            'Professional Tax' => $professional_tax
        ];
        $total_pt += $professional_tax;
    }

    $total_net_pay += $net_pay;
    $total_basic_salary += $basic_salary;
    $total_extra += $extra;
    $total_extra_days_salary += $extra_days_salary;
    $total_bonus += $bonus;
    $total_leave_deduction += $leave_deduction;
    $total_amount += $net_pay;
    $sr++;
}

$excel_data = $data_rows;

if ($filter_type === 'cash') {
    $excel_data[] = [
        'Srno' => '',
        'Employee Name' => 'TOTAL',
        'Net Salary' => $total_net_pay
    ];
} elseif ($filter_type === 'hdfc') {
    $excel_data[] = [
        'Srno' => '',
        'Employee Name' => 'TOTAL',
        'Net Salary' => $total_net_pay,
        'MICR Code' => '',
        'IFSC Code' => '',
        'Beneficiary Account No.' => ''
    ];
} elseif ($filter_type === 'pf') {
    $excel_data[] = [
        'Srno' => '',
        'Name' => 'TOTAL',
        'Basic Salary' => $total_basic_salary,
        'Extra' => $total_extra,
        'Extra Days Salary (₹)' => $total_extra_days_salary,
        'Bonus' => $total_bonus,
        'Leave Deduction' => $total_leave_deduction,
        'Gross Salary' => $total_basic_salary + $total_extra + $total_extra_days_salary + $total_bonus - $total_leave_deduction,
        'Less: Provident Fund' => $total_pf
    ];
} elseif ($filter_type === 'pt') {
    $excel_data[] = [
        'Srno' => '',
        'Name' => 'TOTAL',
        'Professional Tax' => $total_pt
    ];
} else {
    $excel_data[] = [
        'Srno' => '',
        'Employee Name' => 'TOTAL',
        'Net Salary' => $total_net_pay,
        'MICR Code' => '',
        'IFSC Code' => '',
        'Beneficiary Account No.' => ''
    ];
}

if (isset($_POST['download_excel'])) {
    if (empty($excel_data)) {
        $error = "No data available to download. Please apply filters or ensure data exists.";
    } else {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $merge_range = ($filter_type === 'cash' || $filter_type === 'pt') ? 'A1:C1' : ($filter_type === 'pf' ? 'A1:I1' : 'A1:F1');
        $column_count = ($filter_type === 'cash' || $filter_type === 'pt') ? 3 : ($filter_type === 'pf' ? 9 : 6);

        $sheet->setCellValue('A1', "M/S. NILAYKUMAR AND BROS JEWELLERS");
        $sheet->mergeCells($merge_range);
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $sheet->setCellValue('A2', '1ST, 2ND, 3RD, 4TH FLOOR');
        $sheet->setCellValue('A3', 'KRISHNA OPAL');
        $sheet->setCellValue('A4', 'ANAND V V NAGAR ROAD');
        $sheet->setCellValue('A5', 'ANAND - 388001');

        for ($row = 2; $row <= 5; $row++) {
            $sheet->mergeCells("A$row:" . Coordinate::stringFromColumnIndex($column_count) . "$row");
            $sheet->getStyle("A$row")->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        }

        if ($filter_type === 'cash') {
            $sheet->setCellValue('C6', 'Total: ₹' . number_format((float)$total_amount, 2));
            $sheet->setCellValue('A6', $month_filter_display);
            $sheet->getStyle('C6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('C6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
            $sheet->getStyle('A6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('A6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
        } elseif ($filter_type === 'pf') {
            $sheet->setCellValue('H6', 'Total Gross: ₹' . number_format((float)($total_basic_salary + $total_extra + $total_extra_days_salary + $total_bonus - $total_leave_deduction), 2));
            $sheet->setCellValue('I6', $month_filter_display);
            $sheet->getStyle('H6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('H6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
            $sheet->getStyle('I6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('I6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
        } elseif ($filter_type === 'pt') {
            $sheet->setCellValue('C6', 'Total PT: ₹' . number_format((float)$total_pt, 2));
            $sheet->setCellValue('A6', $month_filter_display);
            $sheet->getStyle('C6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('C6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
            $sheet->getStyle('A6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('A6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
        } else {
            $sheet->setCellValue('E6', 'Total: ₹' . number_format((float)$total_amount, 2));
            $sheet->setCellValue('F6', $month_filter_display);
            $sheet->getStyle('E6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('E6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
            $sheet->getStyle('F6')->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle('F6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
        }

        if ($filter_type === 'cash') {
            $headers = ['Srno', 'Employee Name', 'Net Salary'];
        } elseif ($filter_type === 'pf') {
            $headers = ['Srno', 'Name', 'Basic Salary', 'Extra', 'Extra Days Salary (₹)', 'Bonus', 'Leave Deduction', 'Gross Salary', 'Less: Provident Fund'];
        } elseif ($filter_type === 'pt') {
            $headers = ['Srno', 'Name', 'Professional Tax'];
        } else {
            $headers = ['Srno', 'Employee Name', 'Net Salary', 'MICR Code', 'IFSC Code', 'Beneficiary Account No.'];
        }
        $col = 1;
        foreach ($headers as $header) {
            $cell = Coordinate::stringFromColumnIndex($col) . '7';
            $sheet->setCellValue($cell, $header);
            $sheet->getStyle($cell)->getFont()->setBold(true);
            $col++;
        }

        $row_num = 8;
        foreach ($excel_data as $data_row) {
            $col = 1;
            foreach ($data_row as $value) {
                $cell = Coordinate::stringFromColumnIndex($col) . $row_num;
                $sheet->setCellValue($cell, $value);
                $col++;
            }
            $row_num++;
        }

        $column_range = ($filter_type === 'cash' || $filter_type === 'pt') ? range('A', 'C') : ($filter_type === 'pf' ? range('A', 'I') : range('A', 'F'));
        foreach ($column_range as $columnID) {
            $sheet->getColumnDimension($columnID)->setAutoSize(true);
        }

        $filename = "Final_Sheet_" . ($filter_type ?: 'All') . "_" . date('Ymd_His') . ".xlsx";
        try {
            ob_end_clean();
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="' . $filename . '"');
            header('Cache-Control: max-age=0');
            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit();
        } catch (Exception $e) {
            error_log("Error generating Excel: " . $e->getMessage());
            echo "An error occurred while generating the file.";
            exit();
        }
    }
}

if (isset($_POST['download_pf_excel']) && $month_year) {
    if (empty($pf_excel_data)) {
        $error = "No employees with Provident Fund deductions found for the selected month.";
    } else {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', "M/S. NILAYKUMAR AND BROS JEWELLERS");
        $sheet->mergeCells('A1:I1');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $sheet->setCellValue('A2', '1ST, 2ND, 3RD, 4TH FLOOR');
        $sheet->setCellValue('A3', 'KRISHNA OPAL');
        $sheet->setCellValue('A4', 'ANAND V V NAGAR ROAD');
        $sheet->setCellValue('A5', 'ANAND - 388001');

        for ($row = 2; $row <= 5; $row++) {
            $sheet->mergeCells("A$row:I$row");
            $sheet->getStyle("A$row")->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        }

        $sheet->setCellValue('H6', 'Total Gross: ₹' . number_format((float)($total_basic_salary + $total_extra + $total_extra_days_salary + $total_bonus - $total_leave_deduction), 2));
        $sheet->setCellValue('I6', $month_filter_display);
        $sheet->getStyle('H6')->getFont()->setBold(true)->setSize(12);
        $sheet->getStyle('H6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
        $sheet->getStyle('I6')->getFont()->setBold(true)->setSize(12);
        $sheet->getStyle('I6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);

        $headers = ['Srno', 'Name', 'Basic Salary', 'Extra', 'Extra Days Salary (₹)', 'Bonus', 'Leave Deduction', 'Gross Salary', 'Less: Provident Fund'];
        $col = 1;
        foreach ($headers as $header) {
            $cell = Coordinate::stringFromColumnIndex($col) . '7';
            $sheet->setCellValue($cell, $header);
            $sheet->getStyle($cell)->getFont()->setBold(true);
            $col++;
        }

        $row_num = 8;
        foreach ($pf_excel_data as $data_row) {
            $col = 1;
            foreach ($data_row as $value) {
                $cell = Coordinate::stringFromColumnIndex($col) . $row_num;
                $sheet->setCellValue($cell, $value);
                $col++;
            }
            $row_num++;
        }

        $totals_row = $row_num;
        $sheet->setCellValue('A' . $totals_row, '');
        $sheet->setCellValue('B' . $totals_row, 'TOTAL');
        $sheet->setCellValue('C' . $totals_row, $total_basic_salary);
        $sheet->setCellValue('D' . $totals_row, $total_extra);
        $sheet->setCellValue('E' . $totals_row, $total_extra_days_salary);
        $sheet->setCellValue('F' . $totals_row, $total_bonus);
        $sheet->setCellValue('G' . $totals_row, $total_leave_deduction);
        $sheet->setCellValue('H' . $totals_row, $total_basic_salary + $total_extra + $total_extra_days_salary + $total_bonus - $total_leave_deduction);
        $sheet->setCellValue('I' . $totals_row, $total_pf);
        $sheet->getStyle('A' . $totals_row . ':I' . $totals_row)->getFont()->setBold(true);

        foreach (range('A', 'I') as $columnID) {
            $sheet->getColumnDimension($columnID)->setAutoSize(true);
        }

        $filename = "PF_Deductions_" . $month_year . "_" . date('Ymd_His') . ".xlsx";
        try {
            ob_end_clean();
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="' . $filename . '"');
            header('Cache-Control: max-age=0');
            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit();
        } catch (Exception $e) {
            error_log("Error generating PF Excel: " . $e->getMessage());
            echo "An error occurred while generating the PF file.";
            exit();
        }
    }
}

if (isset($_POST['download_pt_excel']) && $month_year) {
    if (empty($pt_excel_data)) {
        $error = "No employees with Professional Tax deductions found for the selected month.";
    } else {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', "M/S. NILAYKUMAR AND BROS JEWELLERS");
        $sheet->mergeCells('A1:C1');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $sheet->setCellValue('A2', '1ST, 2ND, 3RD, 4TH FLOOR');
        $sheet->setCellValue('A3', 'KRISHNA OPAL');
        $sheet->setCellValue('A4', 'ANAND V V NAGAR ROAD');
        $sheet->setCellValue('A5', 'ANAND - 388001');

        for ($row = 2; $row <= 5; $row++) {
            $sheet->mergeCells("A$row:C$row");
            $sheet->getStyle("A$row")->getFont()->setBold(true)->setSize(12);
            $sheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        }

        $sheet->setCellValue('C6', 'Total PT: ₹' . number_format((float)$total_pt, 2));
        $sheet->setCellValue('A6', $month_filter_display);
        $sheet->getStyle('C6')->getFont()->setBold(true)->setSize(12);
        $sheet->getStyle('C6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
        $sheet->getStyle('A6')->getFont()->setBold(true)->setSize(12);
        $sheet->getStyle('A6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);

        $headers = ['Srno', 'Name', 'Professional Tax'];
        $col = 1;
        foreach ($headers as $header) {
            $cell = Coordinate::stringFromColumnIndex($col) . '7';
            $sheet->setCellValue($cell, $header);
            $sheet->getStyle($cell)->getFont()->setBold(true);
            $col++;
        }

        $row_num = 8;
        foreach ($pt_excel_data as $data_row) {
            $col = 1;
            foreach ($data_row as $value) {
                $cell = Coordinate::stringFromColumnIndex($col) . $row_num;
                $sheet->setCellValue($cell, $value);
                $col++;
            }
            $row_num++;
        }

        $totals_row = $row_num;
        $sheet->setCellValue('A' . $totals_row, '');
        $sheet->setCellValue('B' . $totals_row, 'TOTAL');
        $sheet->setCellValue('C' . $totals_row, $total_pt);
        $sheet->getStyle('A' . $totals_row . ':C' . $totals_row)->getFont()->setBold(true);

        foreach (range('A', 'C') as $columnID) {
            $sheet->getColumnDimension($columnID)->setAutoSize(true);
        }

        $filename = "PT_Deductions_" . $month_year . "_" . date('Ymd_His') . ".xlsx";
        try {
            ob_end_clean();
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="' . $filename . '"');
            header('Cache-Control: max-age=0');
            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit();
        } catch (Exception $e) {
            error_log("Error generating PT Excel: " . $e->getMessage());
            echo "An error occurred while generating the PT file.";
            exit();
        }
    }
}

$result->data_seek(0);

$page_title = "Final Sheet";
include 'header.php';
?>

<style>
    .total-salary-box {
        background-color: #28a745;
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        font-weight: bold;
        margin-right: 10px;
    }

    .table-responsive {
        position: relative;
        overflow-x: auto;
        max-height: 500px;
    }

    .table thead th {
        position: sticky;
        top: 0;
        background-color: #34495e;
        z-index: 2;
    }
</style>

<div class="row mb-4">
    <div class="col-md-10 mx-auto">
        <div class="card p-3 shadow-sm">
            <form method="POST" id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label for="month_year" class="form-label">Filter by Month & Year:</label>
                    <?php
                    $default_month_year = date('Y-m');
                    $month_year = isset($_POST['month_year']) && !empty($_POST['month_year']) ? $_POST['month_year'] : $default_month_year;
                    ?>
                    <input type="month" id="month_year" name="month_year" class="form-control" value="<?php echo htmlspecialchars($month_year); ?>">
                </div>
                <div class="col-md-3">
                    <label for="filter_type" class="form-label">Filter by Type:</label>
                    <select id="filter_type" name="filter_type" class="form-select">
                        <option value="">All</option>
                        <option value="cash" <?php echo $filter_type === 'cash' ? 'selected' : ''; ?>>Cash</option>
                        <option value="hdfc" <?php echo $filter_type === 'hdfc' ? 'selected' : ''; ?>>HDFC Bank</option>
                        <option value="other" <?php echo $filter_type === 'other' ? 'selected' : ''; ?>>Other Banks</option>
                        <option value="apprentice" <?php echo $filter_type === 'apprentice' ? 'selected' : ''; ?>>Apprentice</option>
                        <option value="pf" <?php echo $filter_type === 'pf' ? 'selected' : ''; ?>>Provident Fund</option>
                        <option value="pt" <?php echo $filter_type === 'pt' ? 'selected' : ''; ?>>Professional Tax</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="search" class="form-label">Search by Name:</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Enter name" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <label for="sort_order" class="form-label">Sort by Net Salary:</label>
                    <select id="sort_order" name="sort_order" class="form-select">
                        <option value="desc" <?php echo $sort_order === 'desc' ? 'selected' : ''; ?>>High to Low</option>
                        <option value="asc" <?php echo $sort_order === 'asc' ? 'selected' : ''; ?>>Low to High</option>
                    </select>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="text-center mb-0">Final Sheet</h3>
                <div class="d-flex align-items-center">
                    <div class="total-salary-box">
                        Total: ₹<?php echo number_format((float)$total_amount, 2); ?>
                    </div>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="month_year" value="<?php echo htmlspecialchars($month_year); ?>">
                        <input type="hidden" name="filter_type" value="<?php echo htmlspecialchars($filter_type); ?>">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                        <input type="hidden" name="sort_order" value="<?php echo htmlspecialchars($sort_order); ?>">
                        <button type="submit" name="download_excel" class="btn btn-link p-0 mr-2" title="Download as Excel">
                            <i class="fas fa-download fa-2x text-success"></i>
                        </button>
                    </form>
                    <?php if ($filter_type === 'pf' || !$filter_type || $filter_type === 'pt'): ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="month_year" value="<?php echo htmlspecialchars($month_year); ?>">
                        <input type="hidden" name="filter_type" value="pf">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                        <input type="hidden" name="sort_order" value="<?php echo htmlspecialchars($sort_order); ?>">
                        <button type="submit" name="download_pf_excel" class="btn btn-link p-0 mr-2" title="Download PF Excel">
                            <i class="fas fa-file-excel fa-2x text-warning"></i>
                        </button>
                    </form>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="month_year" value="<?php echo htmlspecialchars($month_year); ?>">
                        <input type="hidden" name="filter_type" value="pt">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                        <input type="hidden" name="sort_order" value="<?php echo htmlspecialchars($sort_order); ?>">
                        <button type="submit" name="download_pt_excel" class="btn btn-link p-0" title="Download PT Excel">
                            <i class="fas fa-file-excel fa-2x text-info"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (isset($error)) { echo "<p class='text-danger text-center mb-3'>$error</p>"; } ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <?php if ($filter_type === 'cash') { ?>
                                <th>SR</th>
                                <th>Employee Name</th>
                                <th>Net Salary</th>
                            <?php } elseif ($filter_type === 'hdfc') { ?>
                                <th>Srno</th>
                                <th>Employee Name</th>
                                <th>Net Salary</th>
                                <th>MICR Code</th>
                                <th>IFSC Code</th>
                                <th>Beneficiary Account No</th>
                            <?php } elseif ($filter_type === 'other') { ?>
                                <th>Srno</th>
                                <th>Employee Name</th>
                                <th>Net Salary</th>
                                <th>Value Date</th>
                                <th>Branch Code</th>
                                <th>Sender</th>
                                <th>Remitter Account NO</th>
                                <th>Remitter Name</th>
                                <th>IFSC CODE</th>
                                <th>Debit ACCOUNT</th>
                                <th>Beneficiary Account Type</th>
                                <th>Bank Account Number/Consumer no</th>
                                <th>Beneficiary Name</th>
                                <th>Remittance Details</th>
                                <th>Debit Account System</th>
                                <th>Originator Of Remittance</th>
                                <th>Email/Phone No</th>
                            <?php } elseif ($filter_type === 'pf') { ?>
                                <th>Srno</th>
                                <th>Name</th>
                                <th>Basic Salary</th>
                                <th>Extra</th>
                                <th>Extra Days Salary (₹)</th>
                                <th>Bonus</th>
                                <th>Leave Deduction</th>
                                <th>Gross Salary</th>
                                <th>Less: Provident Fund</th>
                            <?php } elseif ($filter_type === 'pt') { ?>
                                <th>Srno</th>
                                <th>Name</th>
                                <th>Professional Tax</th>
                            <?php } else { ?>
                                <th>Srno</th>
                                <th>Employee Name</th>
                                <th>Net Salary</th>
                                <th>MICR Code</th>
                                <th>IFSC Code</th>
                                <th>Beneficiary Account No</th>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sr = 1;
                        foreach ($data_rows as $row) {
                            $net_salary = isset($row['Net Salary']) ? (float)$row['Net Salary'] : 0;
                            $value_date = $row['value_date'] ?? '-';
                        ?>
                        <tr>
                            <?php if ($filter_type === 'cash') { ?>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['Employee Name']); ?></td>
                                <td><?php echo "₹" . number_format($net_salary, 2); ?></td>
                            <?php } elseif ($filter_type === 'hdfc') { ?>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['Employee Name']); ?></td>
                                <td><?php echo "₹" . number_format($net_salary, 2); ?></td>
                                <td><?php echo htmlspecialchars($row['MICR Code']); ?></td>
                                <td><?php echo htmlspecialchars($row['IFSC Code']); ?></td>
                                <td><?php echo htmlspecialchars($row['Beneficiary Account No.']); ?></td>
                            <?php } elseif ($filter_type === 'other') { ?>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['Employee Name']); ?></td>
                                <td><?php echo "₹" . number_format($net_salary, 2); ?></td>
                                <td><?php echo htmlspecialchars($value_date); ?></td>
                                <td><?php echo htmlspecialchars($company['branch_code'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($company['sender'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($company['remitter_account_no'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($company['remitter_name'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($row['IFSC Code']); ?></td>
                                <td><?php echo htmlspecialchars($company['debit_account'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($company['beneficiary_account_type'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($row['Beneficiary Account No.']); ?></td>
                                <td><?php echo htmlspecialchars($row['Employee Name']); ?></td>
                                <td><?php echo htmlspecialchars($company['remittance_details'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($company['debit_account_system'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($company['originator_of_remittance'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($row['email'] ?: '-'); ?></td>
                            <?php } elseif ($filter_type === 'pf') { ?>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['Name']); ?></td>
                                <td><?php echo "₹" . number_format($row['Basic Salary'], 2); ?></td>
                                <td><?php echo "₹" . number_format($row['Extra'], 2); ?></td>
                                <td><?php echo "₹" . number_format($row['Extra Days Salary (₹)'], 2); ?></td>
                                <td><?php echo "₹" . number_format($row['Bonus'], 2); ?></td>
                                <td><?php echo "₹" . number_format($row['Leave Deduction'], 2); ?></td>
                                <td><?php echo "₹" . number_format($row['Gross Salary'], 2); ?></td>
                                <td><?php echo "₹" . number_format($row['Less: Provident Fund'], 2); ?></td>
                            <?php } elseif ($filter_type === 'pt') { ?>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['Name']); ?></td>
                                <td><?php echo "₹" . number_format($row['Professional Tax'], 2); ?></td>
                            <?php } else { ?>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['Employee Name']); ?></td>
                                <td><?php echo "₹" . number_format($net_salary, 2); ?></td>
                                <td><?php echo htmlspecialchars($row['MICR Code']); ?></td>
                                <td><?php echo htmlspecialchars($row['IFSC Code']); ?></td>
                                <td><?php echo htmlspecialchars($row['Beneficiary Account No.']); ?></td>
                            <?php } ?>
                        </tr>
                        <?php } ?>
                        <tr>
                            <?php if ($filter_type === 'cash') { ?>
                                <td></td>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?php echo "₹" . number_format($total_net_pay, 2); ?></strong></td>
                            <?php } elseif ($filter_type === 'hdfc') { ?>
                                <td></td>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?php echo "₹" . number_format($total_net_pay, 2); ?></strong></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            <?php } elseif ($filter_type === 'other') { ?>
                                <td></td>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?php echo "₹" . number_format($total_net_pay, 2); ?></strong></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            <?php } elseif ($filter_type === 'pf') { ?>
                                <td></td>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?php echo "₹" . number_format($total_basic_salary, 2); ?></strong></td>
                                <td><strong><?php echo "₹" . number_format($total_extra, 2); ?></strong></td>
                                <td><strong><?php echo "₹" . number_format($total_extra_days_salary, 2); ?></strong></td>
                                <td><strong><?php echo "₹" . number_format($total_bonus, 2); ?></strong></td>
                                <td><strong><?php echo "₹" . number_format($total_leave_deduction, 2); ?></strong></td>
                                <td><strong><?php echo "₹" . number_format($total_basic_salary + $total_extra + $total_extra_days_salary + $total_bonus - $total_leave_deduction, 2); ?></strong></td>
                                <td><strong><?php echo "₹" . number_format($total_pf, 2); ?></strong></td>
                            <?php } elseif ($filter_type === 'pt') { ?>
                                <td></td>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?php echo "₹" . number_format($total_pt, 2); ?></strong></td>
                            <?php } else { ?>
                                <td></td>
                                <td><strong>TOTAL</strong></td>
                                <td><strong><?php echo "₹" . number_format($total_net_pay, 2); ?></strong></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            <?php } ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('filterForm');
    const monthYearInput = document.getElementById('month_year');
    const filterTypeInput = document.getElementById('filter_type');
    const searchInput = document.getElementById('search');
    const sortOrderInput = document.getElementById('sort_order');

    monthYearInput.addEventListener('change', function() {
        if (monthYearInput.value) {
            form.submit();
        }
    });

    filterTypeInput.addEventListener('change', function() {
        form.submit();
    });

    let debounceTimeout;
    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            form.submit();
        }, 300);
    });

    sortOrderInput.addEventListener('change', function() {
        form.submit();
    });
});
</script>

<?php include 'footer.php'; ?>