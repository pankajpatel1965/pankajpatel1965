<?php
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Get filter parameters from POST or GET (to preserve across pagination)
$search = isset($_POST['search']) ? mysqli_real_escape_string($conn, $_POST['search']) : (isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '');
$payment_filter = isset($_POST['payment_filter']) ? mysqli_real_escape_string($conn, $_POST['payment_filter']) : (isset($_GET['payment_filter']) ? mysqli_real_escape_string($conn, $_GET['payment_filter']) : '');
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$employees_per_page = 20;

// Build query conditions
$conditions = [];
if ($search !== '') {
    $conditions[] = "name LIKE '%$search%'";
}
if ($payment_filter !== '') {
    switch ($payment_filter) {
        case 'cash':
            $conditions[] = "payment_type = 'cash'";
            break;
        case 'hdfc':
            $conditions[] = "payment_type = 'bank' AND bank_name = 'HDFC'";
            break;
        case 'other':
            $conditions[] = "payment_type = 'bank' AND bank_name = 'Other'";
            break;
        case 'apprentice':
            $conditions[] = "payment_type = 'bank' AND bank_name = 'Apprentice'";
            break;
    }
}

// Count total employees and calculate total salary
$count_query = "SELECT COUNT(*) as total, SUM(salary) as total_salary FROM employees";
if (!empty($conditions)) {
    $count_query .= " WHERE " . implode(" AND ", $conditions);
}
$count_result = mysqli_query($conn, $count_query);
$count_data = mysqli_fetch_assoc($count_result);
$total_employees = $count_data['total'];
$total_salary = $count_data['total_salary'] ?? 0;
$total_pages = ceil($total_employees / $employees_per_page);

// Ensure page is within valid range
$page = max(1, min($page, $total_pages));
$offset = ($page - 1) * $employees_per_page;

// Build main query with pagination
$query = "SELECT * FROM employees";
if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}
$query .= " ORDER BY id LIMIT $offset, $employees_per_page";
$result = mysqli_query($conn, $query);

$page_title = "Dashboard";
include 'header.php';
?>

<div class="row mb-4">
    <div class="col-md-8 mx-auto">
        <div class="card p-3 shadow-sm">
            <form method="POST" id="filterForm" class="row g-3">
                <div class="col-md-6">
                    <label for="search" class="form-label">Search by Name:</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Enter employee name" value="<?php echo htmlspecialchars($search); ?>" autocomplete="off">
                </div>
                <div class="col-md-6">
                    <label for="payment_filter" class="form-label">Filter by Payment Type:</label>
                    <select id="payment_filter" name="payment_filter" class="form-select">
                        <option value="">All</option>
                        <option value="cash" <?php echo $payment_filter === 'cash' ? 'selected' : ''; ?>>Cash</option>
                        <option value="hdfc" <?php echo $payment_filter === 'hdfc' ? 'selected' : ''; ?>>HDFC Bank</option>
                        <option value="other" <?php echo $payment_filter === 'other' ? 'selected' : ''; ?>>Other Banks</option>
                        <option value="apprentice" <?php echo $payment_filter === 'apprentice' ? 'selected' : ''; ?>>Apprentice</option>
                    </select>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0">Employee List</h3>
                <div class="total-salary-box">
                    Total Salary: ₹<?php echo number_format($total_salary, 2); ?>
                </div>
            </div>
            <?php if (mysqli_num_rows($result) == 0) { ?>
                <p class="text-center text-muted">No employees found matching your criteria.</p>
            <?php } else { ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact Number</th>
        <th>Position</th>
        <th>Basic Salary</th>
        <th>Payment Type</th>
        <th>MICR Code</th>
        <th>IFSC Code</th>
        <th>Account Number</th>
        <th>Bank Name</th>
        <th>Provident Fund AC No</th>
        <th>UAN No</th>
        <th>Actions</th>
    </tr>
</thead>

<tbody>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo htmlspecialchars($row['id'] ?? ''); ?></td>
        <td><?php echo htmlspecialchars($row['name'] ?? ''); ?></td>
        <td><?php echo htmlspecialchars($row['email'] ?? '-') ?></td>
        <td><?php echo htmlspecialchars($row['contact_number'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($row['position'] ?? ''); ?></td>
        <td><?php echo "₹" . number_format($row['salary'] ?? 0, 0); ?></td>
        <td><?php echo htmlspecialchars($row['payment_type'] ?? ''); ?></td>
        <td><?php echo htmlspecialchars($row['micr_code'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($row['ifsc_code'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($row['account_number'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($row['bank_name'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($row['provident_fund_ac_no'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($row['uan_no'] ?? '-'); ?></td>
        <td>
            <a href="edit_employee.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="delete_employee.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
        </td>
    </tr>
    <?php } ?>
</tbody>

                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1) { ?>
            <nav aria-label="Employee list pagination" class="mt-4">
                <ul class="pagination justify-content-center">
                    <!-- Previous Button -->
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="#" onclick="<?php echo $page > 1 ? 'preserveFilters(' . ($page - 1) . ')' : 'return false'; ?>">Previous</a>
                    </li>

                    <!-- Page Numbers -->
                    <?php
                    $range = 2;
                    $start = max(1, $page - $range);
                    $end = min($total_pages, $page + $range);

                    if ($start > 2) {
                        echo '<li class="page-item"><a class="page-link" href="#" onclick="preserveFilters(1)">1</a></li>';
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }

                    for ($i = $start; $i <= $end; $i++) {
                        echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
                        echo '<a class="page-link" href="#" onclick="preserveFilters(' . $i . ')">' . $i . '</a>';
                        echo '</li>';
                    }

                    if ($end < $total_pages - 1) {
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        echo '<li class="page-item"><a class="page-link" href="#" onclick="preserveFilters(' . $total_pages . ')">' . $total_pages . '</a></li>';
                    }
                    ?>

                    <!-- Next Button -->
                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="#" onclick="<?php echo $page < $total_pages ? 'preserveFilters(' . ($page + 1) . ')' : 'return false'; ?>">Next</a>
                    </li>
                </ul>
            </nav>
            <?php } ?>
            <?php } ?>
        </div>
    </div>
</div>

<style>
.table-responsive {
    position: relative;
    overflow-x: auto;
    max-height: 500px; /* Adjust the height as needed */
}

.table thead th {
    position: sticky;
    top: 0;
    background-color: #34495e; /* Background color for the sticky header */
    z-index: 2;
    box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4); /* Optional: Add shadow for better visibility */
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search');
    const paymentFilter = document.getElementById('payment_filter');
    const form = document.getElementById('filterForm');

    // Function to submit form with delay (debouncing)
    let timeoutId;
    function submitForm() {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            // Update the URL with GET parameters to preserve state
            const url = new URL(window.location.href);
            url.searchParams.set('search', searchInput.value);
            url.searchParams.set('payment_filter', paymentFilter.value);
            url.searchParams.set('page', 1); // Reset to page 1 on filter change
            window.history.pushState({}, '', url);
            form.submit();
        }, 500);
    }

    // Submit form when search input changes
    searchInput.addEventListener('input', submitForm);

    // Submit form when payment filter changes
    paymentFilter.addEventListener('change', submitForm);

    // Restore focus and cursor position after page reload
    const currentValue = searchInput.value;
    if (currentValue) {
        searchInput.focus();
        searchInput.setSelectionRange(currentValue.length, currentValue.length);
    }

    // Function to preserve filters when changing pages
    window.preserveFilters = function(page) {
        const form = document.getElementById('filterForm');
        const url = new URL(window.location.href);
        url.searchParams.set('page', page);
        url.searchParams.set('search', searchInput.value);
        url.searchParams.set('payment_filter', paymentFilter.value);
        window.history.pushState({}, '', url);

        // Add hidden inputs for form submission
        const hiddenPage = document.createElement('input');
        hiddenPage.type = 'hidden';
        hiddenPage.name = 'page';
        hiddenPage.value = page;
        form.appendChild(hiddenPage);

        const hiddenSearch = document.createElement('input');
        hiddenSearch.type = 'hidden';
        hiddenSearch.name = 'search';
        hiddenSearch.value = searchInput.value;
        form.appendChild(hiddenSearch);

        const hiddenPayment = document.createElement('input');
        hiddenPayment.type = 'hidden';
        hiddenPayment.name = 'payment_filter';
        hiddenPayment.value = paymentFilter.value;
        form.appendChild(hiddenPayment);

        form.submit();
    }
});
</script>

<?php include 'footer.php'; ?>