<?php
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: salary.php");
    exit();
}

$id = $_GET['id'];
$salary_query = "SELECT s.*, e.name, e.salary AS basic_salary, e.payment_type 
                 FROM salaries s 
                 JOIN employees e ON s.employee_id = e.id 
                 WHERE s.id = ?";
$stmt = $conn->prepare($salary_query);
$stmt->bind_param("i", $id);
$stmt->execute();
$salary = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$salary) {
    header("Location: salary.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $month_year = $_POST['month_year'];
    $value_date = $_POST['value_date'];
    $basic_salary = $_POST['basic_salary'];
    $extra_days = !empty($_POST['extra_days']) ? $_POST['extra_days'] : NULL;
    $extra = !empty($_POST['extra']) ? $_POST['extra'] : NULL;
    $bonus = !empty($_POST['bonus']) ? $_POST['bonus'] : NULL;
    $leave_full_days = !empty($_POST['leave_full_days']) ? $_POST['leave_full_days'] : NULL;
    $leave_half_days = !empty($_POST['leave_half_days']) ? $_POST['leave_half_days'] : NULL;
    $deduct_pf = isset($_POST['deduct_pf']) ? 1 : 0;
    $late_charge = !empty($_POST['late_charge']) ? $_POST['late_charge'] : NULL;
    $deposit = !empty($_POST['deposit']) ? $_POST['deposit'] : NULL;
    $withdrawal = !empty($_POST['withdrawal']) ? $_POST['withdrawal'] : NULL;
    $uniform = !empty($_POST['uniform']) ? $_POST['uniform'] : NULL;

    // Calculate Gross Salary
    $daily_rate = $basic_salary / 30;
    $extra_days_salary = round($daily_rate * ($extra_days ?? 0)); // Renamed to extra_days_salary
    $leave_deduction = round(($leave_full_days + ($leave_half_days * 0.5)) * $daily_rate);
    $gross_salary = round($basic_salary + $extra_days_salary + ($extra ?? 0) + ($bonus ?? 0) - $leave_deduction);

    // Calculate Provident Fund (PF)
    $pf = NULL;
    if ($deduct_pf && $salary['payment_type'] !== 'cash') {
        $pf = min(round($gross_salary * 0.12), 1800);
    }

    // Calculate Professional Tax
    $professional_tax = ($gross_salary >= 12000) ? 200 : 0;

    // Calculate Net Pay
    $net_pay = round($gross_salary - ($pf ?? 0) - $professional_tax - ($late_charge ?? 0) - ($deposit ?? 0) - ($withdrawal ?? 0) - ($uniform ?? 0));

    $sql = "UPDATE salaries SET 
            month_year = ?, 
            value_date = ?, 
            total_salary = ?, 
            extra_days = ?, 
            extra_days_salary = ?, 
            extra = ?, 
            bonus = ?, 
            leave_full_days = ?, 
            leave_half_days = ?, 
            deduct_pf = ?, 
            pf = ?, 
            professional_tax = ?, 
            late_charge = ?, 
            deposit = ?, 
            withdrawal = ?, 
            uniform = ?, 
            gross_salary = ?, 
            net_pay = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);

    $types = "ssd"; // month_year (s), value_date (s), total_salary (d)
    $values = [$month_year, $value_date, $basic_salary];

    function addParam(&$types, &$values, $value) {
        if ($value === NULL) {
            $types .= 's';
            $values[] = NULL;
        } else {
            $types .= 'd';
            $values[] = $value;
        }
    }

    addParam($types, $values, $extra_days);
    addParam($types, $values, $extra_days_salary); // Added extra_days_salary
    addParam($types, $values, $extra);
    addParam($types, $values, $bonus);
    addParam($types, $values, $leave_full_days);
    addParam($types, $values, $leave_half_days);

    $types .= 'i'; // deduct_pf (integer)
    $values[] = $deduct_pf;

    addParam($types, $values, $pf);
    addParam($types, $values, $professional_tax);
    addParam($types, $values, $late_charge);
    addParam($types, $values, $deposit);
    addParam($types, $values, $withdrawal);
    addParam($types, $values, $uniform);
    addParam($types, $values, $gross_salary);
    addParam($types, $values, $net_pay);

    $types .= 'i'; // id (integer)
    $values[] = $id;

    $stmt->bind_param($types, ...$values);

    if ($stmt->execute()) {
        header("Location: salary.php");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
    $stmt->close();
}

$page_title = "Edit Salary";
include 'header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card p-4">
            <h3 class="text-center mb-4">Edit Salary for <?php echo htmlspecialchars($salary['name']); ?></h3>
            <?php if (isset($error)) { echo "<p class='text-danger text-center mb-3'>$error</p>"; } ?>
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="month_year" class="form-label">Month & Year:</label>
                        <input type="month" id="month_year" name="month_year" class="form-control" value="<?php echo htmlspecialchars($salary['month_year']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="value_date" class="form-label">Value Date:</label>
                        <input type="date" id="value_date" name="value_date" class="form-control" value="<?php echo htmlspecialchars($salary['value_date']); ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="basic_salary" class="form-label">Basic Salary (₹):</label>
                        <input type="number" id="basic_salary" name="basic_salary" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['total_salary']); ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="extra_days" class="form-label">Extra Days:</label>
                        <input type="number" id="extra_days" name="extra_days" class="form-control" step="0.01" value="<?php echo htmlspecialchars($salary['extra_days']); ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="extra_days_salary" class="form-label">Extra Days Salary (₹):</label>
                        <input type="number" id="extra_days_salary" class="form-control" disabled step="1" value="<?php echo htmlspecialchars($salary['extra_days_salary']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="extra" class="form-label">Extra (₹):</label>
                        <input type="number" id="extra" name="extra" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['extra']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="bonus" class="form-label">Bonus (₹):</label>
                        <input type="number" id="bonus" name="bonus" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['bonus']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="leave_full_days" class="form-label">Leave Full Days:</label>
                        <input type="number" id="leave_full_days" name="leave_full_days" class="form-control" step="0.01" value="<?php echo htmlspecialchars($salary['leave_full_days']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="leave_half_days" class="form-label">Leave Half Days:</label>
                        <input type="number" id="leave_half_days" name="leave_half_days" class="form-control" step="0.01" value="<?php echo htmlspecialchars($salary['leave_half_days']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="leave_deduction" class="form-label">Leave Deduction (₹):</label>
                        <input type="number" id="leave_deduction" class="form-control" disabled step="1">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="gross_salary" class="form-label">Gross Salary (₹):</label>
                        <input type="number" id="gross_salary" class="form-control" disabled step="1" value="<?php echo htmlspecialchars($salary['gross_salary']); ?>">
                    </div>
                </div>
                <div class="row" id="pf_section" style="<?php echo ($salary['payment_type'] === 'cash') ? 'display: none;' : 'display: flex;'; ?>">
                    <div class="col-md-6 mb-3">
                        <label for="deduct_pf" class="form-label">Provident Fund:</label>
                        <input type="checkbox" id="deduct_pf" name="deduct_pf" class="form-check-input" <?php echo $salary['deduct_pf'] ? 'checked' : ''; ?>>
                        <small class="form-text text-muted">Check to deduct 12% of gross salary (max ₹1800)</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="pf" class="form-label">Less: Provident Fund (₹):</label>
                        <input type="number" id="pf" class="form-control" disabled step="1">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="professional_tax" class="form-label">Less: Professional Tax (₹):</label>
                        <input type="number" id="professional_tax" class="form-control" disabled step="1">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="late_charge" class="form-label">Less: Late Charge (₹):</label>
                        <input type="number" id="late_charge" name="late_charge" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['late_charge']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="deposit" class="form-label">Less: Deposit (₹):</label>
                        <input type="number" id="deposit" name="deposit" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['deposit']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="withdrawal" class="form-label">Less: Withdrawal (₹):</label>
                        <input type="number" id="withdrawal" name="withdrawal" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['withdrawal']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="uniform" class="form-label">Less: Uniform (₹):</label>
                        <input type="number" id="uniform" name="uniform" class="form-control" step="1" value="<?php echo htmlspecialchars($salary['uniform']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="net_pay" class="form-label">Net Pay (₹):</label>
                        <input type="number" id="net_pay" class="form-control" disabled step="1" value="<?php echo htmlspecialchars($salary['net_pay']); ?>">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Update Salary</button>
                <a href="salary.php" class="btn btn-secondary w-100 mt-3">Back to Salary List</a>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const basicSalaryInput = document.getElementById('basic_salary');
    const extraDaysInput = document.getElementById('extra_days');
    const extraDaysSalaryInput = document.getElementById('extra_days_salary'); // Updated ID
    const extraInput = document.getElementById('extra');
    const bonusInput = document.getElementById('bonus');
    const leaveFullDaysInput = document.getElementById('leave_full_days');
    const leaveHalfDaysInput = document.getElementById('leave_half_days');
    const leaveDeductionInput = document.getElementById('leave_deduction');
    const grossSalaryInput = document.getElementById('gross_salary');
    const deductPfCheckbox = document.getElementById('deduct_pf');
    const pfInput = document.getElementById('pf');
    const pfSection = document.getElementById('pf_section');
    const professionalTaxInput = document.getElementById('professional_tax');
    const lateChargeInput = document.getElementById('late_charge');
    const depositInput = document.getElementById('deposit');
    const withdrawalInput = document.getElementById('withdrawal');
    const uniformInput = document.getElementById('uniform');
    const netPayInput = document.getElementById('net_pay');

    function calculateSalaries() {
        const basicSalary = Math.round(parseFloat(basicSalaryInput.value) || 0);
        const extraDays = parseFloat(extraDaysInput.value) || 0;
        const extra = Math.round(parseFloat(extraInput.value) || 0);
        const bonus = Math.round(parseFloat(bonusInput.value) || 0);
        const leaveFullDays = parseFloat(leaveFullDaysInput.value) || 0;
        const leaveHalfDays = parseFloat(leaveHalfDaysInput.value) || 0;
        const lateCharge = Math.round(parseFloat(lateChargeInput.value) || 0);
        const deposit = Math.round(parseFloat(depositInput.value) || 0);
        const withdrawal = Math.round(parseFloat(withdrawalInput.value) || 0);
        const uniform = Math.round(parseFloat(uniformInput.value) || 0);

        const dailyRate = basicSalary / 30;
        const extraDaysSalary = Math.round(dailyRate * extraDays); // Renamed to extraDaysSalary
        const leaveDeduction = Math.round((leaveFullDays + leaveHalfDays * 0.5) * dailyRate);

        extraDaysSalaryInput.value = extraDaysSalary; // Updated ID
        leaveDeductionInput.value = leaveDeduction;

        const grossSalary = Math.round(basicSalary + extraDaysSalary + extra + bonus - leaveDeduction);
        grossSalaryInput.value = grossSalary;

        let pf = 0;
        if (pfSection.style.display !== 'none' && deductPfCheckbox.checked) {
            pf = Math.min(Math.round(grossSalary * 0.12), 1800);
        }
        pfInput.value = pf;

        const professionalTax = grossSalary >= 12000 ? 200 : 0;
        professionalTaxInput.value = professionalTax;

        const netPay = Math.round(grossSalary - pf - professionalTax - lateCharge - deposit - withdrawal - uniform);
        netPayInput.value = netPay;
    }

    calculateSalaries();

    basicSalaryInput.addEventListener('input', calculateSalaries);
    extraDaysInput.addEventListener('input', calculateSalaries);
    extraInput.addEventListener('input', calculateSalaries);
    bonusInput.addEventListener('input', calculateSalaries);
    leaveFullDaysInput.addEventListener('input', calculateSalaries);
    leaveHalfDaysInput.addEventListener('input', calculateSalaries);
    deductPfCheckbox.addEventListener('change', calculateSalaries);
    lateChargeInput.addEventListener('input', calculateSalaries);
    depositInput.addEventListener('input', calculateSalaries);
    withdrawalInput.addEventListener('input', calculateSalaries);
    uniformInput.addEventListener('input', calculateSalaries);
});
</script>

<?php include 'footer.php'; ?>