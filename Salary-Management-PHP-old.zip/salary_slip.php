<?php
ob_start();
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Include FPDF library
require __DIR__ . '/vendor/autoload.php';
use setasign\Fpdi\Fpdi;

// Fetch company details
$company = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM company_details LIMIT 1"));

// Get current month and year as default
$current_month_year = date('Y-m');

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($page - 1) * $records_per_page;

// Fetch salary data with filters
$month_year = isset($_POST['month_year']) ? $_POST['month_year'] : (isset($_GET['month_year']) ? $_GET['month_year'] : $current_month_year);
$filter_type = isset($_POST['filter_type']) ? $_POST['filter_type'] : (isset($_GET['filter_type']) ? $_GET['filter_type'] : '');
$search = isset($_POST['search']) ? mysqli_real_escape_string($conn, $_POST['search']) : (isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '');
$employees_data = [];

// Query for display (with pagination)
if ($month_year) {
    $query = "SELECT e.id, e.uan_no, e.name, e.payment_type, e.bank_name, s.month_year, s.value_date, s.total_salary, 
              s.extra_days, s.extra, s.bonus, s.leave_full_days, s.leave_half_days, s.pf, s.professional_tax, 
              s.late_charge, s.deposit, s.withdrawal, s.uniform, s.gross_salary, s.net_pay, s.extra_days_salary 
              FROM employees e 
              JOIN salaries s ON e.id = s.employee_id 
              WHERE s.month_year = ?";
    $conditions = [];
    $params = [$month_year];
    $types = "s";

    if ($filter_type) {
        if ($filter_type === 'cash') {
            $conditions[] = "e.payment_type = ?";
            $params[] = 'cash';
            $types .= "s";
        } elseif ($filter_type === 'hdfc') {
            $conditions[] = "e.payment_type = ? AND e.bank_name = ?";
            $params[] = 'bank';
            $params[] = 'HDFC';
            $types .= "ss";
        } elseif ($filter_type === 'other') {
            $conditions[] = "e.payment_type = ? AND e.bank_name = ?";
            $params[] = 'bank';
            $params[] = 'Other';
            $types .= "ss";
        } elseif ($filter_type === 'apprentice') {
            $conditions[] = "e.payment_type = ? AND e.bank_name = ?";
            $params[] = 'bank';
            $params[] = 'Apprentice';
            $types .= "ss";
        }
    }

    if ($search) {
        $conditions[] = "e.name LIKE ?";
        $params[] = "%$search%";
        $types .= "s";
    }

    if (!empty($conditions)) {
        $query .= " AND " . implode(" AND ", $conditions);
    }

    // Count total records for pagination
    $count_query = "SELECT COUNT(*) as total FROM employees e JOIN salaries s ON e.id = s.employee_id WHERE s.month_year = ?";
    if (!empty($conditions)) {
        $count_query .= " AND " . implode(" AND ", $conditions);
    }
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->bind_param($types, ...$params);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $count_data = $count_result->fetch_assoc();
    $total_records = $count_data['total'];
    $total_pages = ceil($total_records / $records_per_page);

    // Ensure page is within valid range
    $page = max(1, min($page, $total_pages));
    $offset = ($page - 1) * $records_per_page;

    // Add pagination to main query for display
    $display_query = $query . " ORDER BY e.name LIMIT ?, ?";
    $display_params = array_merge($params, [$offset, $records_per_page]);
    $display_types = $types . "ii";

    $stmt = $conn->prepare($display_query);
    $stmt->bind_param($display_types, ...$display_params);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $basic_salary = round($row['total_salary'] ?? 0);
        $daily_rate = $basic_salary / 30;
        $extra_days = $row['extra_days'] ?? 0;
        $extra = round($row['extra'] ?? 0);
        $bonus = round($row['bonus'] ?? 0);
        $leave_full_days = $row['leave_full_days'] ?? 0;
        $leave_half_days = $row['leave_half_days'] ?? 0;
        $late_charge = round($row['late_charge'] ?? 0);
        $deposit = round($row['deposit'] ?? 0);
        $withdrawal = round($row['withdrawal'] ?? 0);
        $uniform = round($row['uniform'] ?? 0);
        $pf = round($row['pf'] ?? 0);
        $professional_tax = round($row['professional_tax'] ?? 0);
        $gross_salary = round($row['gross_salary'] ?? 0);
        $net_pay = round($row['net_pay'] ?? 0);
        $extra_days_salary = round($row['extra_days_salary'] ?? 0);

        $extra_days_pay = round($daily_rate * $extra_days);
        $leave_deduction = round(($leave_full_days + $leave_half_days * 0.5) * $daily_rate);
        $value_date = $row['value_date'] ? (new DateTime($row['value_date']))->format('d/m/Y') : '-';

        $employees_data[] = [
            'uan_no' => $row['uan_no'] ?? 'N/A',
            'name' => $row['name'],
            'month' => date('M-y', strtotime($row['month_year'] . '-01')),
            'value_date' => $value_date,
            'basic_salary' => $basic_salary,
            'extra_days' => $extra_days,
            'extra' => $extra,
            'bonus' => $bonus,
            'leave_days' => $leave_full_days + $leave_half_days * 0.5,
            'leave_deduction' => $leave_deduction,
            'pf' => $pf,
            'professional_tax' => $professional_tax,
            'late_charge' => $late_charge,
            'deposit' => $deposit,
            'withdrawal' => $withdrawal,
            'uniform' => $uniform,
            'gross_salary' => $gross_salary,
            'net_pay' => $net_pay,
            'extra_days_salary' => $extra_days_salary
        ];
    }
    $stmt->close();
    $count_stmt->close();
}

// Generate and download PDF if requested
if (isset($_POST['download_pdf']) && $month_year) {
    // Fetch all records for PDF (no pagination)
    $pdf_query = $query;

    // Add ORDER BY clause when filter_type is empty (All selected)
    if (empty($filter_type)) {
        $pdf_query .= " ORDER BY 
            CASE 
                WHEN e.payment_type = 'cash' THEN 1
                WHEN e.payment_type = 'bank' AND e.bank_name = 'HDFC' THEN 2
                WHEN e.payment_type = 'bank' AND e.bank_name = 'Other' THEN 3
                WHEN e.payment_type = 'bank' AND e.bank_name = 'Apprentice' THEN 4
                ELSE 5
            END, e.name";
    } else {
        $pdf_query .= " ORDER BY e.name";
    }

    $pdf_stmt = $conn->prepare($pdf_query);
    $pdf_stmt->bind_param($types, ...$params);
    $pdf_stmt->execute();
    $pdf_result = $pdf_stmt->get_result();

    $pdf_employees_data = [];
    while ($row = $pdf_result->fetch_assoc()) {
        $basic_salary = round($row['total_salary'] ?? 0);
        $daily_rate = $basic_salary / 30;
        $extra_days = $row['extra_days'] ?? 0;
        $extra = round($row['extra'] ?? 0);
        $bonus = round($row['bonus'] ?? 0);
        $leave_full_days = $row['leave_full_days'] ?? 0;
        $leave_half_days = $row['leave_half_days'] ?? 0;
        $late_charge = round($row['late_charge'] ?? 0);
        $deposit = round($row['deposit'] ?? 0);
        $withdrawal = round($row['withdrawal'] ?? 0);
        $uniform = round($row['uniform'] ?? 0);
        $pf = round($row['pf'] ?? 0);
        $professional_tax = round($row['professional_tax'] ?? 0);
        $gross_salary = round($row['gross_salary'] ?? 0);
        $net_pay = round($row['net_pay'] ?? 0);
        $extra_days_salary = round($row['extra_days_salary'] ?? 0);

        $extra_days_pay = round($daily_rate * $extra_days);
        $leave_deduction = round(($leave_full_days + $leave_half_days * 0.5) * $daily_rate);
        $value_date = $row['value_date'] ? (new DateTime($row['value_date']))->format('d/m/Y') : '-';

        $pdf_employees_data[] = [
            'uan_no' => $row['uan_no'] ?? 'N/A',
            'name' => $row['name'],
            'month' => date('M-y', strtotime($row['month_year'] . '-01')),
            'value_date' => $value_date,
            'basic_salary' => $basic_salary,
            'extra_days' => $extra_days,
            'extra' => $extra,
            'bonus' => $bonus,
            'leave_days' => $leave_full_days + $leave_half_days * 0.5,
            'leave_deduction' => $leave_deduction,
            'pf' => $pf,
            'professional_tax' => $professional_tax,
            'late_charge' => $late_charge,
            'deposit' => $deposit,
            'withdrawal' => $withdrawal,
            'uniform' => $uniform,
            'gross_salary' => $gross_salary,
            'net_pay' => $net_pay,
            'extra_days_salary' => $extra_days_salary
        ];
    }
    $pdf_stmt->close();

    if (!empty($pdf_employees_data)) {
        try {
            $pdf = new FPDF('P', 'mm', 'A4');
            $pdf->SetMargins(10, 10, 10);
            $pdf->SetAutoPageBreak(false);

            $y_position = 10;
            $page_height = 297;
            $margin_bottom = 10;
            $max_y = $page_height - $margin_bottom;
            $pdf->AddPage();

            for ($i = 0; $i < count($pdf_employees_data); $i++) {
                $fields = [
                    'NAME' => $pdf_employees_data[$i]['name'],
                    'UAN NUMBER' => empty($pdf_employees_data[$i]['uan_no']) ? 'N/A' : $pdf_employees_data[$i]['uan_no'],
                    'SR.NO' => $i + 1,
                    'MONTH' => $pdf_employees_data[$i]['month'],
                    'BASIC SALARY' => $pdf_employees_data[$i]['basic_salary'],
                    'EXTRA' => $pdf_employees_data[$i]['extra'],
                    'BONUS' => $pdf_employees_data[$i]['bonus'],
                    'EXTRA DAYS' => $pdf_employees_data[$i]['extra_days'],
                    'EXTRA DAYS SALARY' => $pdf_employees_data[$i]['extra_days_salary'],
                    'LESS DAYS' => $pdf_employees_data[$i]['leave_days'],
                    'LESS LEAVES' => $pdf_employees_data[$i]['leave_deduction'],
                    'GROSS SALARY' => $pdf_employees_data[$i]['gross_salary'],
                    'LESS: PF' => $pdf_employees_data[$i]['pf'],
                    'LESS: PROFESSIONAL TAX' => $pdf_employees_data[$i]['professional_tax'],
                    'LESS: LATE CHARGE' => $pdf_employees_data[$i]['late_charge'],
                    'LESS: DEPOSIT' => $pdf_employees_data[$i]['deposit'],
                    'LESS: WITHDRAWAL' => $pdf_employees_data[$i]['withdrawal'],
                    'LESS: UNIFORM' => $pdf_employees_data[$i]['uniform'],
                    'NET SALARY' => $pdf_employees_data[$i]['net_pay']
                ];

                $field_count = 0;
                foreach ($fields as $label => $value) {
                    if ($value != 0 || in_array($label, ['SR.NO', 'UAN NUMBER', 'MONTH', 'NAME', 'BASIC SALARY', 'GROSS SALARY', 'NET SALARY'])) {
                        $field_count++;
                    }
                }

                $header_height = 30;
                $line_height = 5;
                $slip_height = $header_height + ($field_count * $line_height);

                if ($y_position + $slip_height > $max_y) {
                    $pdf->AddPage();
                    $y_position = 10;
                }

                $pdf->SetXY(10, $y_position);
                $pdf->SetDrawColor(0, 0, 0);
                $pdf->Rect(10, $y_position, 190, $slip_height, 'D');

                // Company name and address
                $pdf->SetFont('Arial', 'B', 14);
                $pdf->SetXY(10, $y_position + 5);
                $pdf->Cell(190, 8, strtoupper($company['company_name']), 0, 1, 'C');
                $pdf->SetFont('Arial', '', 10);
                $pdf->SetXY(10, $y_position + 13);
                $pdf->Cell(190, 6, $company['address'] ?: 'Address Not Set', 0, 1, 'C');
                $pdf->SetFont('Arial', '', 12);
                $pdf->SetXY(10, $y_position + 19);
                $pdf->Cell(190, 6, "Salary Slip", 0, 1, 'C');

                $pdf->SetFont('Arial', '', 12);
                $pdf->SetXY(150, $y_position + 5);
                $pdf->Cell(50, 6, $pdf_employees_data[$i]['value_date'], 0, 1, 'R');

                $pdf->SetLineWidth(0.5);
                $pdf->Line(10, $y_position + 25, 200, $y_position + 25);

                // Salary slip details
                $pdf->SetFont('Arial', '', 12);
                $current_y = $y_position + 30;

                foreach ($fields as $label => $value) {
                    if ($value != 0 || in_array($label, ['SR.NO', 'UAN NUMBER', 'MONTH', 'NAME', 'BASIC SALARY', 'GROSS SALARY', 'NET SALARY'])) {
                        $pdf->SetXY(20, $current_y);
                        if ($label === 'NET SALARY' || $label === 'GROSS SALARY') {
                            $pdf->SetFont('Arial', 'B', 12);
                        }
                        $pdf->Cell(80, 5, $label, 0, 0, 'L');
                        $pdf->Cell(50, 5, $value, 0, 1, 'R');
                        if ($label === 'NET SALARY' || $label === 'GROSS SALARY') {
                            $pdf->SetFont('Arial', '', 12);
                        }
                        $current_y += 5;
                    }
                }
                $y_position = $current_y + 10;
            }

            $filename = "Salary_Slips_" . $month_year . "_" . ($filter_type ?: 'All') . ".pdf";
            ob_end_clean();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment;filename="' . $filename . '"');
            header('Cache-Control: max-age=0');
            $pdf->Output('D', $filename);
            exit();
        } catch (Exception $e) {
            error_log("Error generating PDF: " . $e->getMessage());
            echo "An error occurred while generating the PDF file.";
            exit();
        }
    } else {
        $error = "No data available to generate PDF.";
    }
}

$page_title = "Generate Salary Slips";
include 'header.php';
?>

<div class="row mb-4">
    <div class="col-md-10 mx-auto">
        <div class="card p-3 shadow-sm">
            <form method="POST" id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label for="month_year" class="form-label">Select Month & Year:</label>
                    <input type="month" id="month_year" name="month_year" class="form-control" value="<?php echo htmlspecialchars($month_year); ?>" required>
                </div>
                <div class="col-md-3">
                    <label for="search" class="form-label">Search by Name:</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Enter name" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <label for="filter_type" class="form-label">Filter by Type:</label>
                    <select id="filter_type" name="filter_type" class="form-select">
                        <option value="" <?php echo $filter_type === '' ? 'selected' : ''; ?>>All</option>
                        <option value="cash" <?php echo $filter_type === 'cash' ? 'selected' : ''; ?>>Cash</option>
                        <option value="hdfc" <?php echo $filter_type === 'hdfc' ? 'selected' : ''; ?>>HDFC Bank</option>
                        <option value="other" <?php echo $filter_type === 'other' ? 'selected' : ''; ?>>Other Banks</option>
                        <option value="apprentice" <?php echo $filter_type === 'apprentice' ? 'selected' : ''; ?>>Apprentice</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" name="download_pdf" class="btn btn-primary w-100">Download Salary Slips</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($month_year): ?>
<div class="row">
    <div class="col-12">
        <div class="card p-4">
            <h3 class="text-center mb-4">Salary Slip Data</h3>
            <?php if (isset($error)): ?>
                <p class="text-danger text-center mb-3"><?php echo $error; ?></p>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>SR.NO</th>
                            <th>NAME</th>
                            <th>BASIC SALARY</th>
                            <th>EXTRA</th>
                            <th>BONUS</th>
                            <th>EXTRA DAYS</th>
                            <th>EXTRA DAYS SALARY (₹)</th>
                            <th>LESS DAYS</th>
                            <th>LESS LEAVES</th>
                            <th>GROSS SALARY</th>
                            <th>LESS: PF</th>
                            <th>LESS: PROFESSIONAL TAX</th>
                            <th>LESS: LATE CHARGE</th>
                            <th>LESS: DEPOSIT</th>
                            <th>LESS: WITHDRAWAL</th>
                            <th>LESS: UNIFORM</th>
                            <th>VALUE DATE</th>
                            <th>UAN_NO</th>
                            <th>MONTH</th>
                            <th>NET SALARY</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($employees_data)): ?>
                            <tr>
                                <td colspan="20" class="text-center">No salary slips available for the selected filters.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($employees_data as $index => $employee): ?>
                                <tr>
                                    <td><?php echo $offset + $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($employee['name']); ?></td>
                                    <td><?php echo htmlspecialchars($employee['basic_salary']); ?></td>
                                    <td><?php echo $employee['extra'] ? htmlspecialchars($employee['extra']) : '-'; ?></td>
                                    <td><?php echo $employee['bonus'] ? htmlspecialchars($employee['bonus']) : '-'; ?></td>
                                    <td><?php echo $employee['extra_days'] ? htmlspecialchars($employee['extra_days']) : '-'; ?></td>
                                    <td><?php echo $employee['extra_days_salary'] ? htmlspecialchars($employee['extra_days_salary']) : '-'; ?></td>
                                    <td><?php echo $employee['leave_days'] ? htmlspecialchars($employee['leave_days']) : '-'; ?></td>
                                    <td><?php echo $employee['leave_deduction'] ? htmlspecialchars($employee['leave_deduction']) : '-'; ?></td>
                                    <td><?php echo htmlspecialchars($employee['gross_salary']); ?></td>
                                    <td><?php echo $employee['pf'] ? htmlspecialchars($employee['pf']) : '-'; ?></td>
                                    <td><?php echo $employee['professional_tax'] ? htmlspecialchars($employee['professional_tax']) : '-'; ?></td>
                                    <td><?php echo $employee['late_charge'] ? htmlspecialchars($employee['late_charge']) : '-'; ?></td>
                                    <td><?php echo $employee['deposit'] ? htmlspecialchars($employee['deposit']) : '-'; ?></td>
                                    <td><?php echo $employee['withdrawal'] ? htmlspecialchars($employee['withdrawal']) : '-'; ?></td>
                                    <td><?php echo $employee['uniform'] ? htmlspecialchars($employee['uniform']) : '-'; ?></td>
                                    <td><?php echo htmlspecialchars($employee['value_date']); ?></td>
                                    <td><?php echo htmlspecialchars($employee['uan_no']); ?></td>
                                    <td><?php echo htmlspecialchars($employee['month']); ?></td>
                                    <td><?php echo htmlspecialchars($employee['net_pay']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav aria-label="Salary slip pagination" class="mt-4">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="#" onclick="<?php echo $page > 1 ? 'preserveFilters(' . ($page - 1) . ')' : 'return false'; ?>">Previous</a>
                    </li>
                    <?php
                    $range = 2;
                    $start = max(1, $page - $range);
                    $end = min($total_pages, $page + $range);

                    if ($start > 2) {
                        echo '<li class="page-item"><a class="page-link" href="#" onclick="preserveFilters(1)">1</a></li>';
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }

                    for ($i = $start; $i <= $end; $i++) {
                        echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
                        echo '<a class="page-link" href="#" onclick="preserveFilters(' . $i . ')">' . $i . '</a>';
                        echo '</li>';
                    }

                    if ($end < $total_pages - 1) {
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        echo '<li class="page-item"><a class="page-link" href="#" onclick="preserveFilters(' . $total_pages . ')">' . $total_pages . '</a></li>';
                    }
                    ?>
                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="#" onclick="<?php echo $page < $total_pages ? 'preserveFilters(' . ($page + 1) . ')' : 'return false'; ?>">Next</a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
.table-responsive {
    position: relative;
    overflow-x: auto;
    max-height: 500px;
}

.table thead th {
    position: sticky;
    top: 0;
    background-color: #34495e;
    z-index: 2;
    box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('filterForm');
    const monthYearInput = document.getElementById('month_year');
    const searchInput = document.getElementById('search');
    const filterTypeInput = document.getElementById('filter_type');

    // Debounce function to limit form submissions
    let debounceTimeout;
    function submitForm() {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            const url = new URL(window.location.href);
            url.searchParams.set('month_year', monthYearInput.value);
            url.searchParams.set('search', searchInput.value);
            url.searchParams.set('filter_type', filterTypeInput.value);
            url.searchParams.set('page', 1);
            window.history.pushState({}, '', url);
            form.submit();
        }, 300);
    }

    monthYearInput.addEventListener('change', function() {
        if (monthYearInput.value) {
            submitForm();
        }
    });

    searchInput.addEventListener('input', submitForm);

    filterTypeInput.addEventListener('change', submitForm);

    const currentSearchValue = searchInput.value;
    if (currentSearchValue) {
        searchInput.focus();
        searchInput.setSelectionRange(currentSearchValue.length, currentSearchValue.length);
    }

    window.preserveFilters = function(page) {
        const url = new URL(window.location.href);
        url.searchParams.set('page', page);
        url.searchParams.set('month_year', monthYearInput.value);
        url.searchParams.set('search', searchInput.value);
        url.searchParams.set('filter_type', filterTypeInput.value);
        window.history.pushState({}, '', url);

        const hiddenPage = document.createElement('input');
        hiddenPage.type = 'hidden';
        hiddenPage.name = 'page';
        hiddenPage.value = page;
        form.appendChild(hiddenPage);

        const hiddenMonthYear = document.createElement('input');
        hiddenMonthYear.type = 'hidden';
        hiddenMonthYear.name = 'month_year';
        hiddenMonthYear.value = monthYearInput.value;
        form.appendChild(hiddenMonthYear);

        const hiddenSearch = document.createElement('input');
        hiddenSearch.type = 'hidden';
        hiddenSearch.name = 'search';
        hiddenSearch.value = searchInput.value;
        form.appendChild(hiddenSearch);

        const hiddenFilterType = document.createElement('input');
        hiddenFilterType.type = 'hidden';
        hiddenFilterType.name = 'filter_type';
        hiddenFilterType.value = filterTypeInput.value;
        form.appendChild(hiddenFilterType);

        form.submit();
    }
});
</script>

<?php include 'footer.php'; ?>