<?php
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$employee = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM employees WHERE id = '$id'"));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];
    $payment_type = $_POST['payment_type'];
    $contact_number = $_POST['contact_number'];
    $micr_code = $payment_type === 'bank' ? $_POST['micr_code'] : NULL;
    $ifsc_code = $payment_type === 'bank' ? $_POST['ifsc_code'] : NULL;
    $account_number = $payment_type === 'bank' ? $_POST['account_number'] : NULL;
    $bank_name = $payment_type === 'bank' ? $_POST['bank_name'] : NULL;
    $provident_fund_ac_no = $payment_type === 'bank' ? $_POST['provident_fund_ac_no'] : NULL;
    $uan_no = $payment_type === 'bank' ? $_POST['uan_no'] : NULL;

    $sql = "UPDATE employees SET 
            name = ?, 
            email = ?, 
            position = ?, 
            salary = ?, 
            payment_type = ?, 
            micr_code = ?, 
            ifsc_code = ?, 
            account_number = ?, 
            bank_name = ?, 
            provident_fund_ac_no = ?, 
            uan_no = ?, 
            contact_number = ?
            WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssi", $name, $email, $position, $salary, $payment_type, $micr_code, $ifsc_code, $account_number, $bank_name, $provident_fund_ac_no, $uan_no, $contact_number, $id);
            
    if ($stmt->execute()) {
        header("Location: index.php");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
    $stmt->close();
}

$page_title = "Edit Employee";
include 'header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card p-4">
            <h3 class="text-center mb-4">Edit Employee</h3>
            <?php if (isset($error)) { echo "<p class='text-danger text-center mb-3'>$error</p>"; } ?>
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">Name:</label>
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($employee['name']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($employee['email']); ?>" >
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="position" class="form-label">Position:</label>
                        <input type="text" id="position" name="position" class="form-control" value="<?php echo htmlspecialchars($employee['position']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="salary" class="form-label">Salary (₹):</label>
                        <input type="number" id="salary" name="salary" class="form-control" step="1" value="<?php echo htmlspecialchars($employee['salary']); ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="contact_number" class="form-label">Contact Number:</label>
                        <input type="text" id="contact_number" name="contact_number" class="form-control" maxlength="20" value="<?php echo htmlspecialchars($employee['contact_number']); ?>" placeholder="e.g., +919876543210">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="payment_type" class="form-label">Payment Type:</label>
                        <select id="payment_type" name="payment_type" class="form-select" required>
                            <option value="cash" <?php echo $employee['payment_type'] === 'cash' ? 'selected' : ''; ?>>Cash</option>
                            <option value="bank" <?php echo $employee['payment_type'] === 'bank' ? 'selected' : ''; ?>>Bank</option>
                        </select>
                    </div>
                </div>
                <div id="bank_fields" style="display: <?php echo $employee['payment_type'] === 'bank' ? 'block' : 'none'; ?>;">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label for="bank_name" class="form-label">Bank Name:</label>
                            <select id="bank_name" name="bank_name" class="form-select">
                                <option value="HDFC" <?php echo $employee['bank_name'] === 'HDFC' ? 'selected' : ''; ?>>HDFC</option>
                                <option value="Other" <?php echo $employee['bank_name'] === 'Other' ? 'selected' : ''; ?>>Other</option>
                                <option value="Apprentice" <?php echo $employee['bank_name'] === 'Apprentice' ? 'selected' : ''; ?>>Apprentice</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="micr_code" class="form-label">MICR Code:</label>
                            <input type="text" id="micr_code" name="micr_code" class="form-control" value="<?php echo htmlspecialchars($employee['micr_code']); ?>" maxlength="9">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="ifsc_code" class="form-label">IFSC Code:</label>
                            <input type="text" id="ifsc_code" name="ifsc_code" class="form-control" value="<?php echo htmlspecialchars($employee['ifsc_code']); ?>" maxlength="11">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="account_number" class="form-label">Account Number:</label>
                            <input type="text" id="account_number" name="account_number" class="form-control" value="<?php echo htmlspecialchars($employee['account_number']); ?>" maxlength="20">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="provident_fund_ac_no" class="form-label">Provident Fund A/C No:</label>
                            <input type="text" id="provident_fund_ac_no" name="provident_fund_ac_no" class="form-control" value="<?php echo htmlspecialchars($employee['provident_fund_ac_no']); ?>" maxlength="50">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="uan_no" class="form-label">UAN No:</label>
                            <input type="text" id="uan_no" name="uan_no" class="form-control" value="<?php echo htmlspecialchars($employee['uan_no']); ?>" maxlength="50">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Update Employee</button>
                <a href="index.php" class="btn btn-secondary w-100 mt-3">Back to List</a>
            </form>
        </div>
    </div>
</div>

<script>
    document.getElementById('payment_type').addEventListener('change', function() {
        const bankFields = document.getElementById('bank_fields');
        const requiredInputs = bankFields.querySelectorAll('#micr_code, #ifsc_code, #account_number');
        const bankNameSelect = document.getElementById('bank_name');
        if (this.value === 'bank') {
            bankFields.style.display = 'block';
            for (let input of requiredInputs) input.required = true;
            bankNameSelect.required = true;
        } else {
            bankFields.style.display = 'none';
            for (let input of requiredInputs) input.required = false;
            bankNameSelect.required = false;
        }
    });
</script>

<?php include 'footer.php'; ?>