<?php
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST['employee_id'];
    $month_year = $_POST['month_year'];
    $value_date = $_POST['value_date'];
    $total_salary = $_POST['total_salary'];
    $extra_days = !empty($_POST['extra_days']) ? $_POST['extra_days'] : NULL;
    $extra = !empty($_POST['extra']) ? $_POST['extra'] : NULL;
    $bonus = !empty($_POST['bonus']) ? $_POST['bonus'] : NULL;
    $leave_full_days = !empty($_POST['leave_full_days']) ? $_POST['leave_full_days'] : NULL;
    $leave_half_days = !empty($_POST['leave_half_days']) ? $_POST['leave_half_days'] : NULL;
    $deduct_pf = isset($_POST['deduct_pf']) ? 1 : 0;
    $late_charge = !empty($_POST['late_charge']) ? $_POST['late_charge'] : NULL;
    $deposit = !empty($_POST['deposit']) ? $_POST['deposit'] : NULL;
    $withdrawal = !empty($_POST['withdrawal']) ? $_POST['withdrawal'] : NULL;
    $uniform = !empty($_POST['uniform']) ? $_POST['uniform'] : NULL;

    // Calculate Extra Days Salary
    $daily_rate = $total_salary / 30;
    $extra_days_salary = round($daily_rate * ($extra_days ?? 0));

    // Calculate Leave Deduction
    $leave_deduction = round(($leave_full_days + ($leave_half_days * 0.5)) * $daily_rate);

    // Calculate Gross Salary
    $gross_salary = round($total_salary + $extra_days_salary + ($extra ?? 0) + ($bonus ?? 0) - $leave_deduction);

    // Calculate Provident Fund (PF)
    $pf = NULL;
    if ($deduct_pf) {
        $pf = min(round($gross_salary * 0.12), 1800);
    }

    // Calculate Professional Tax
    $professional_tax = ($gross_salary >= 12000) ? 200 : 0;

    // Calculate Net Pay
    $net_pay = round($gross_salary - ($pf ?? 0) - $professional_tax - ($late_charge ?? 0) - ($deposit ?? 0) - ($withdrawal ?? 0) - ($uniform ?? 0));

    // Check if salary data already exists
    $check_sql = "SELECT * FROM salaries WHERE employee_id = ? AND month_year = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("is", $employee_id, $month_year);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $error = "Salary data for this employee for $month_year already exists!";
    } else {
        // Insert into database
        $sql = "INSERT INTO salaries (employee_id, month_year, value_date, total_salary, extra_days, extra_days_salary, extra, bonus, leave_full_days, leave_half_days, deduct_pf, pf, professional_tax, late_charge, deposit, withdrawal, uniform, gross_salary, net_pay) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        // Define parameter types and values
        $types = "iss"; // employee_id (i), month_year (s), value_date (s)
        $values = [$employee_id, $month_year, $value_date];

        // Helper function to add parameters
        function addParam(&$types, &$values, $value, $type = 'd') {
            if ($value === NULL) {
                $types .= 's'; // NULL is treated as string in bind_param
                $values[] = NULL;
            } else {
                $types .= $type; // d for decimal, i for integer
                $values[] = $value;
            }
        }

        addParam($types, $values, $total_salary, 'd'); // total_salary
        addParam($types, $values, $extra_days, 'd');
        addParam($types, $values, $extra_days_salary, 'd');
        addParam($types, $values, $extra, 'd');
        addParam($types, $values, $bonus, 'd');
        addParam($types, $values, $leave_full_days, 'd');
        addParam($types, $values, $leave_half_days, 'd');
        addParam($types, $values, $deduct_pf, 'i'); // deduct_pf (integer)
        addParam($types, $values, $pf, 'd');
        addParam($types, $values, $professional_tax, 'd');
        addParam($types, $values, $late_charge, 'd');
        addParam($types, $values, $deposit, 'd');
        addParam($types, $values, $withdrawal, 'd');
        addParam($types, $values, $uniform, 'd');
        addParam($types, $values, $gross_salary, 'd');
        addParam($types, $values, $net_pay, 'd');

        $stmt->bind_param($types, ...$values);

        if ($stmt->execute()) {
            header("Location: salary.php");
            exit();
        } else {
            $error = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    $check_stmt->close();
}

$page_title = "Add Salary";
include 'header.php';
?>

<!-- Include Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card p-4">
            <h3 class="text-center mb-4">Add Monthly Salary</h3>
            <?php if (isset($error)) { echo "<p class='text-danger text-center mb-3'>$error</p>"; } ?>
            <form method="POST" id="salaryForm">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="month_year" class="form-label">Month & Year:</label>
                        <?php
                        // Set default to previous month-year
                        $previous_month = new DateTime('first day of last month');
                        $default_month_year = $previous_month->format('Y-m');
                        $month_year = isset($_POST['month_year']) && !empty($_POST['month_year']) ? $_POST['month_year'] : $default_month_year;
                        ?>
                        <input type="month" id="month_year" name="month_year" class="form-control" value="<?php echo htmlspecialchars($month_year); ?>" required>
                    </div>
                    <div class="col-md-5 mb-3">
                        <label for="employee_id" class="form-label">Employee:</label>
                        <select id="employee_id" name="employee_id" class="form-select" required style="width: 100%;">
                            <option value="">Select Employee</option>
                        </select>
                        <div id="searched_name" class="mt-2 text-muted" style="display: none;">Searched for: <span id="searched_term"></span></div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="value_date" class="form-label">Value Date:</label>
                        <input type="date" id="value_date" name="value_date" class="form-control" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="total_salary" class="form-label">Basic Salary (₹):</label>
                        <input type="number" id="total_salary" name="total_salary" class="form-control" step="0.01" readonly required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="extra_days" class="form-label">Extra Days:</label>
                        <input type="number" id="extra_days" name="extra_days" class="form-control" step="0.01">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="extra_days_salary" class="form-label">Extra Days Salary (₹):</label>
                        <input type="number" id="extra_days_salary" class="form-control" disabled step="0.01">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="extra" class="form-label">Extra (₹):</label>
                        <input type="number" id="extra" name="extra" class="form-control" step="0.01">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="bonus" class="form-label">Bonus (₹):</label>
                        <input type="number" id="bonus" name="bonus" class="form-control" step="0.01">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="leave_full_days" class="form-label">Leave Full Days:</label>
                        <input type="number" id="leave_full_days" name="leave_full_days" class="form-control" step="0.01">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="leave_half_days" class="form-label">Leave Half Days:</label>
                        <input type="number" id="leave_half_days" name="leave_half_days" class="form-control" step="0.01">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="leave_deduction" class="form-label">Leave Deduction (₹):</label>
                        <input type="number" id="leave_deduction" class="form-control" disabled step="0.01">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="gross_salary" class="form-label">Gross Salary (₹):</label>
                        <input type="number" id="gross_salary" class="form-control" disabled step="0.01">
                    </div>
                </div>
                <div class="row" id="pf_section">
                    <div class="col-md-6 mb-3">
                        <label for="deduct_pf" class="form-label">Provident Fund:</label>
                        <input type="checkbox" id="deduct_pf" name="deduct_pf" class="form-check-input">
                        <small class="form-text text-muted">Check to deduct 12% of gross salary (max ₹1800)</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="pf" class="form-label">Less: Provident Fund (₹):</label>
                        <input type="number" id="pf" class="form-control" disabled step="0.01">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="professional_tax" class="form-label">Less: Professional Tax (₹):</label>
                        <input type="number" id="professional_tax" class="form-control" disabled step="0.01">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="late_charge" class="form-label">Less: Late Charge (₹):</label>
                        <input type="number" id="late_charge" name="late_charge" class="form-control" step="0.01">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="deposit" class="form-label">Less: Deposit (₹):</label>
                        <input type="number" id="deposit" name="deposit" class="form-control" step="0.01">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="withdrawal" class="form-label">Less: Withdrawal (₹):</label>
                        <input type="number" id="withdrawal" name="withdrawal" class="form-control" step="0.01">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="uniform" class="form-label">Less: Uniform (₹):</label>
                        <input type="number" id="uniform" name="uniform" class="form-control" step="0.01">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="net_pay" class="form-label">Net Pay (₹):</label>
                        <input type="number" id="net_pay" class="form-control" disabled step="0.01">
                    </div>
                </div>
                <div id="bank_details" style="display: none;">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Bank Name:</label>
                            <input type="text" id="bank_name_display" class="form-control" disabled>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">MICR Code:</label>
                            <input type="text" id="micr_display" class="form-control" disabled>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">IFSC Code:</label>
                            <input type="text" id="ifsc_display" class="form-control" disabled>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Account Number:</label>
                            <input type="text" id="account_display" class="form-control" disabled>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Add Salary</button>
                <a href="salary.php" class="btn btn-secondary w-100 mt-3">Back to Salary List</a>
            </form>
        </div>
    </div>
</div>

<!-- Include jQuery and Select2 JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const monthYearInput = document.getElementById('month_year');
    const employeeSelect = document.getElementById('employee_id');
    const totalSalaryInput = document.getElementById('total_salary');
    const extraDaysInput = document.getElementById('extra_days');
    const extraDaysSalaryInput = document.getElementById('extra_days_salary');
    const extraInput = document.getElementById('extra');
    const bonusInput = document.getElementById('bonus');
    const leaveFullDaysInput = document.getElementById('leave_full_days');
    const leaveHalfDaysInput = document.getElementById('leave_half_days');
    const leaveDeductionInput = document.getElementById('leave_deduction');
    const grossSalaryInput = document.getElementById('gross_salary');
    const deductPfCheckbox = document.getElementById('deduct_pf');
    const pfInput = document.getElementById('pf');
    const pfSection = document.getElementById('pf_section');
    const professionalTaxInput = document.getElementById('professional_tax');
    const lateChargeInput = document.getElementById('late_charge');
    const depositInput = document.getElementById('deposit');
    const withdrawalInput = document.getElementById('withdrawal');
    const uniformInput = document.getElementById('uniform');
    const netPayInput = document.getElementById('net_pay');
    const bankDetails = document.getElementById('bank_details');
    const bankNameDisplay = document.getElementById('bank_name_display');
    const micrDisplay = document.getElementById('micr_display');
    const ifscDisplay = document.getElementById('ifsc_display');
    const accountDisplay = document.getElementById('account_display');
    const searchedNameDisplay = document.getElementById('searched_name');
    const searchedTermSpan = document.getElementById('searched_term');

    // Initialize Select2
    $(employeeSelect).select2({
        placeholder: "Search by full name",
        allowClear: true,
        width: '100%',
        dropdownAutoWidth: true,
        minimumInputLength: 0
    });

    // Function to fetch employees based on month_year
    function fetchEmployees(monthYear) {
        if (!monthYear) {
            $(employeeSelect).empty().append('<option value="">Select Month First</option>').trigger('change');
            return;
        }

        fetch('get_available_employees.php?month_year=' + encodeURIComponent(monthYear))
            .then(response => response.json())
            .then(data => {
                $(employeeSelect).empty().append('<option value="">Select Employee</option>');

                if (data.error) {
                    alert('Error: ' + data.error);
                    $(employeeSelect).prop('disabled', true);
                    return;
                }

                if (data.employees.length === 0) {
                    alert('No employees available for the selected month.');
                    $(employeeSelect).prop('disabled', true);
                    return;
                }

                $(employeeSelect).prop('disabled', false);

                const groups = {
                    'Cash': [],
                    'HDFC Bank': [],
                    'Other Bank': [],
                    'Apprentice': []
                };

                data.employees.forEach(employee => {
                    if (employee.payment_type === 'cash') {
                        groups['Cash'].push(employee);
                    } else if (employee.payment_type === 'bank') {
                        if (employee.bank_name === 'HDFC') {
                            groups['HDFC Bank'].push(employee);
                        } else if (employee.bank_name === 'Other') {
                            groups['Other Bank'].push(employee);
                        } else if (employee.bank_name === 'Apprentice') {
                            groups['Apprentice'].push(employee);
                        }
                    }
                });

                ['Cash', 'HDFC Bank', 'Other Bank', 'Apprentice'].forEach(groupName => {
                    if (groups[groupName].length > 0) {
                        const optgroup = $('<optgroup>').attr('label', groupName);
                        groups[groupName].forEach(employee => {
                            const option = $('<option>')
                                .val(employee.id)
                                .text(employee.name)
                                .attr('data-salary', employee.salary)
                                .attr('data-payment', employee.payment_type)
                                .attr('data-bank-name', employee.bank_name || '')
                                .attr('data-micr', employee.micr_code || '')
                                .attr('data-ifsc', employee.ifsc_code || '')
                                .attr('data-account', employee.account_number || '');
                            optgroup.append(option);
                        });
                        $(employeeSelect).append(optgroup);
                    }
                });

                $(employeeSelect).trigger('change');
            })
            .catch(error => {
                console.error('Error fetching employees:', error);
                alert('Failed to load employees. Please check your connection or try again later.');
                $(employeeSelect).prop('disabled', true);
            });
    }

    // Fetch employees on month_year change
    monthYearInput.addEventListener('change', function() {
        fetchEmployees(this.value);
        // Reset form fields
        totalSalaryInput.value = '';
        bankDetails.style.display = 'none';
        pfSection.style.display = 'flex';
        deductPfCheckbox.checked = false;
        calculateSalaries();
    });

    // Fetch employees on page load
    if (monthYearInput.value) {
        fetchEmployees(monthYearInput.value);
    } else {
        $(employeeSelect).empty().append('<option value="">Select Month First</option>').trigger('change');
        $(employeeSelect).prop('disabled', true);
    }

    // Calculate salaries
    function calculateSalaries() {
        const totalSalary = parseFloat(totalSalaryInput.value) || 0;
        const extraDays = parseFloat(extraDaysInput.value) || 0;
        const extra = parseFloat(extraInput.value) || 0;
        const bonus = parseFloat(bonusInput.value) || 0;
        const leaveFullDays = parseFloat(leaveFullDaysInput.value) || 0;
        const leaveHalfDays = parseFloat(leaveHalfDaysInput.value) || 0;
        const lateCharge = parseFloat(lateChargeInput.value) || 0;
        const deposit = parseFloat(depositInput.value) || 0;
        const withdrawal = parseFloat(withdrawalInput.value) || 0;
        const uniform = parseFloat(uniformInput.value) || 0;

        const dailyRate = totalSalary / 30;
        const extraDaysSalary = Math.round(dailyRate * extraDays * 100) / 100;
        const leaveDeduction = Math.round((leaveFullDays + leaveHalfDays * 0.5) * dailyRate * 100) / 100;

        extraDaysSalaryInput.value = extraDaysSalary.toFixed(2);
        leaveDeductionInput.value = leaveDeduction.toFixed(2);

        const grossSalary = Math.round((totalSalary + extraDaysSalary + extra + bonus - leaveDeduction) * 100) / 100;
        grossSalaryInput.value = grossSalary.toFixed(2);

        let pf = 0;
        if (pfSection.style.display !== 'none' && deductPfCheckbox.checked) {
            pf = Math.min(Math.round(grossSalary * 0.12 * 100) / 100, 1800);
        }
        pfInput.value = pf.toFixed(2);

        const professionalTax = grossSalary >= 12000 ? 200 : 0;
        professionalTaxInput.value = professionalTax.toFixed(2);

        const netPay = Math.round((grossSalary - pf - professionalTax - lateCharge - deposit - withdrawal - uniform) * 100) / 100;
        netPayInput.value = netPay.toFixed(2);
    }

    // Handle employee selection
    $(employeeSelect).on('select2:select', function(e) {
        const selectedOption = e.params.data.element;
        totalSalaryInput.value = parseFloat(selectedOption.dataset.salary || 0).toFixed(2);

        // Show/hide PF section based on payment type
        if (selectedOption.dataset.payment === 'cash') {
            pfSection.style.display = 'none';
            deductPfCheckbox.checked = false;
        } else {
            pfSection.style.display = 'flex';
        }

        // Show/hide bank details
        if (selectedOption.dataset.payment === 'bank') {
            bankDetails.style.display = 'block';
            bankNameDisplay.value = selectedOption.dataset.bankName || '';
            micrDisplay.value = selectedOption.dataset.micr || '';
            ifscDisplay.value = selectedOption.dataset.ifsc || '';
            accountDisplay.value = selectedOption.dataset.account || '';
        } else {
            bankDetails.style.display = 'none';
            bankNameDisplay.value = '';
            micrDisplay.value = '';
            ifscDisplay.value = '';
            accountDisplay.value = '';
        }

        // Display searched term
        const searchedTerm = $(this).select2('data')[0].text;
        searchedTermSpan.textContent = searchedTerm;
        searchedNameDisplay.style.display = 'block';

        calculateSalaries();
    });

    // Clear searched term on unselect
    $(employeeSelect).on('select2:unselect', function() {
        searchedNameDisplay.style.display = 'none';
        totalSalaryInput.value = '';
        bankDetails.style.display = 'none';
        pfSection.style.display = 'flex';
        deductPfCheckbox.checked = false;
        calculateSalaries();
    });

    // Recalculate salaries on input changes
    [extraDaysInput, extraInput, bonusInput, leaveFullDaysInput, leaveHalfDaysInput, deductPfCheckbox, lateChargeInput, depositInput, withdrawalInput, uniformInput].forEach(input => {
        input.addEventListener('input', calculateSalaries);
    });

    // Prevent form submission if no employee is selected
    document.getElementById('salaryForm').addEventListener('submit', function(e) {
        if (!employeeSelect.value) {
            e.preventDefault();
            alert('Please select an employee.');
        }
    });
});
</script>

<?php include 'footer.php'; ?>