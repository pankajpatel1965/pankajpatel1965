<?php
ob_start();
session_start();
include 'db_connect.php';

// Include PHPspreadsheet autoloader
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Check login status early
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Handle Excel export at the top before any output
if (isset($_POST['export_excel']) && isset($_POST['month_year']) && !empty($_POST['month_year'])) {
    $month_year = $_POST['month_year'];
    $search = isset($_POST['search']) ? mysqli_real_escape_string($conn, $_POST['search']) : '';
    $sort_order = isset($_POST['sort_order']) ? $_POST['sort_order'] : 'desc';
    $filter_type = isset($_POST['filter_type']) ? $_POST['filter_type'] : 'all';

    // Build query conditions for export (no pagination)
    $conditions = ["s.month_year = ?"];
    $params = [$month_year];
    $types = "s";
    if ($search) {
        $conditions[] = "e.name LIKE ?";
        $params[] = "%$search%";
        $types .= "s";
    }
    if ($filter_type !== 'all') {
        if ($filter_type === 'Cash') {
            $conditions[] = "e.payment_type = 'cash'";
        } elseif ($filter_type === 'HDFC Bank') {
            $conditions[] = "e.payment_type = 'bank' AND e.bank_name = 'HDFC'";
        } elseif ($filter_type === 'Apprentice') {
            $conditions[] = "e.payment_type = 'bank' AND e.bank_name = 'Apprentice'";
        } elseif ($filter_type === 'Other Bank') {
            $conditions[] = "e.payment_type = 'bank' AND e.bank_name = 'Other'";
        }
    }

    $export_query = "SELECT e.id AS employee_id, s.id AS salary_id, e.name, s.month_year, s.total_salary, s.extra_days, s.extra, s.bonus, 
                     s.leave_full_days, s.leave_half_days, s.pf, s.late_charge, s.deposit, s.withdrawal, s.uniform, s.professional_tax, 
                     e.payment_type, e.bank_name, s.gross_salary, s.net_pay 
                     FROM employees e 
                     JOIN salaries s ON e.id = s.employee_id";
    if (!empty($conditions)) {
        $export_query .= " WHERE " . implode(" AND ", $conditions);
    }
    $export_query .= " ORDER BY s.net_pay " . ($sort_order === 'asc' ? 'ASC' : 'DESC');

    $export_stmt = $conn->prepare($export_query);
    if (!empty($params)) {
        $export_stmt->bind_param($types, ...$params);
    }
    $export_stmt->execute();
    $export_result = $export_stmt->get_result();

    if ($export_result->num_rows === 0) {
        echo "No data available to export.";
        exit();
    }

    try {
        // Create a new Spreadsheet object
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set headers
        $headers = [
            'SR', 'Name', 'Month-Year', 'Basic Salary', 'Extra Days', 'Extra Days Salary', 'Extra', 'Bonus', 
            'Leave Full Days', 'Leave Half Days', 'Leave Deduction', 'Gross Salary', 'Provident Fund', 
            'Professional Tax', 'Late Charge', 'Deposit', 'Withdrawal', 'Uniform', 'Net Salary', 'Payment Type'
        ];
        $sheet->fromArray($headers, NULL, 'A1');

        // Add data
        $row_number = 2;
        $sr = 1;
        while ($row = $export_result->fetch_assoc()) {
            $basic_salary = (int)round($row['total_salary'] ?? 0, 0);
            $daily_rate = $basic_salary / 30;
            $extra_days = $row['extra_days'] ?? 0;
            $extra = (int)round($row['extra'] ?? 0, 0);
            $bonus = (int)round($row['bonus'] ?? 0, 0);
            $leave_full_days = $row['leave_full_days'] ?? 0;
            $leave_half_days = $row['leave_half_days'] ?? 0;
            $late_charge = (int)round($row['late_charge'] ?? 0, 0);
            $deposit = (int)round($row['deposit'] ?? 0, 0);
            $withdrawal = (int)round($row['withdrawal'] ?? 0, 0);
            $uniform = (int)round($row['uniform'] ?? 0, 0);
            $pf = (int)round($row['pf'] ?? 0, 0);
            $professional_tax = (int)round($row['professional_tax'] ?? 0, 0);
            $gross_salary = (int)round($row['gross_salary'] ?? 0, 0);
            $net_pay = (int)round($row['net_pay'] ?? 0, 0);

            $extra_days_salary = (int)round($daily_rate * $extra_days, 0);
            $leave_deduction = (int)round(($leave_full_days + $leave_half_days * 0.5) * $daily_rate, 0);
            $display_payment_type = $row['payment_type'] === 'cash' ? 'Cash' : ($row['bank_name'] ? $row['bank_name'] . ' Bank' : 'Bank');

            $sheet->fromArray([
                $sr++, $row['name'], $row['month_year'], $basic_salary, $extra_days, $extra_days_salary, 
                $extra, $bonus, $leave_full_days, $leave_half_days, $leave_deduction, $gross_salary, 
                $pf, $professional_tax, $late_charge, $deposit, $withdrawal, $uniform, $net_pay, 
                $display_payment_type
            ], NULL, 'A' . $row_number);
            $row_number++;
        }

        // Set column widths
        foreach (range('A', 'T') as $column) {
            $sheet->getColumnDimension($column)->setAutoSize(true);
        }

        // Create Excel file and download
        $writer = new Xlsx($spreadsheet);
        $filename = "Salaries_$month_year.xlsx";
        ob_end_clean();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
        $export_stmt->close();
        exit();
    } catch (Exception $e) {
        error_log("Error generating Excel: " . $e->getMessage());
        echo "An error occurred while generating the Excel file.";
        exit();
    }
}

// Page rendering starts here
$page_title = "View Salaries";
include 'header.php';

// Get current month and year (set to previous month by default)
$current_month_year = date('Y-m', strtotime('first day of previous month'));

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$salaries_per_page = 10;

// Get filter and sort parameters
$month_year = isset($_POST['month_year']) ? $_POST['month_year'] : (isset($_GET['month_year']) ? $_GET['month_year'] : $current_month_year);
$search = isset($_POST['search']) ? mysqli_real_escape_string($conn, $_POST['search']) : (isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '');
$sort_order = isset($_POST['sort_order']) ? $_POST['sort_order'] : (isset($_GET['sort_order']) ? $_GET['sort_order'] : 'desc');
$filter_type = isset($_POST['filter_type']) ? $_POST['filter_type'] : (isset($_GET['filter_type']) ? $_GET['filter_type'] : 'all');

// Build query conditions for display
$conditions = [];
$params = [];
$types = "";
if ($month_year) {
    $conditions[] = "s.month_year = ?";
    $params[] = $month_year;
    $types .= "s";
}
if ($search) {
    $conditions[] = "e.name LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}
if ($filter_type !== 'all') {
    if ($filter_type === 'Cash') {
        $conditions[] = "e.payment_type = 'cash'";
    } elseif ($filter_type === 'HDFC Bank') {
        $conditions[] = "e.payment_type = 'bank' AND e.bank_name = 'HDFC'";
    } elseif ($filter_type === 'Apprentice') {
        $conditions[] = "e.payment_type = 'bank' AND e.bank_name = 'Apprentice'";
    } elseif ($filter_type === 'Other Bank') {
        $conditions[] = "e.payment_type = 'bank' AND e.bank_name = 'Other'";
    }
}

// Count total salaries
$count_query = "SELECT COUNT(*) as total FROM employees e JOIN salaries s ON e.id = s.employee_id";
if (!empty($conditions)) {
    $count_query .= " WHERE " . implode(" AND ", $conditions);
}
$count_stmt = $conn->prepare($count_query);
if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$count_data = $count_result->fetch_assoc();
$total_salaries = $count_data['total'];
$total_pages = ceil($total_salaries / $salaries_per_page);

// Ensure page is within valid range
$page = max(1, min($page, $total_pages));
$offset = ($page - 1) * $salaries_per_page;

// Query to calculate totals
$total_query = "SELECT 
    SUM(s.total_salary) AS total_basic_salary,
    SUM(s.extra) AS total_extra,
    SUM(s.bonus) AS total_bonus,
    SUM(s.pf) AS total_pf,
    SUM(s.professional_tax) AS total_professional_tax,
    SUM(s.late_charge) AS total_late_charge,
    SUM(s.deposit) AS total_deposit,
    SUM(s.withdrawal) AS total_withdrawal,
    SUM(s.uniform) AS total_uniform,
    SUM(s.gross_salary) AS total_gross_salary,
    SUM(s.net_pay) AS total_net_pay,
    SUM(ROUND((s.leave_full_days + s.leave_half_days * 0.5) * (s.total_salary / 30))) AS total_leave_deduction,
    SUM(ROUND((s.total_salary / 30) * s.extra_days)) AS total_extra_days_salary,
    SUM(s.extra_days) AS total_extra_days,
    SUM(s.leave_full_days) AS total_leave_full_days,
    SUM(s.leave_half_days) AS total_leave_half_days
FROM employees e 
JOIN salaries s ON e.id = s.employee_id";
if (!empty($conditions)) {
    $total_query .= " WHERE " . implode(" AND ", $conditions);
}
$total_stmt = $conn->prepare($total_query);
if (!empty($params)) {
    $total_stmt->bind_param($types, ...$params);
}
$total_stmt->execute();
$total_result = $total_stmt->get_result();
$totals = $total_result->fetch_assoc();

$total_basic_salary = round($totals['total_basic_salary'] ?? 0, 0);
$total_extra = round($totals['total_extra'] ?? 0, 0);
$total_bonus = round($totals['total_bonus'] ?? 0, 0);
$total_leave_deduction = round($totals['total_leave_deduction'] ?? 0, 0);
$total_gross_salary = round($totals['total_gross_salary'] ?? 0, 0);
$total_pf = round($totals['total_pf'] ?? 0, 0);
$total_professional_tax = round($totals['total_professional_tax'] ?? 0, 0);
$total_late_charge = round($totals['total_late_charge'] ?? 0, 0);
$total_deposit = round($totals['total_deposit'] ?? 0, 0);
$total_withdrawal = round($totals['total_withdrawal'] ?? 0, 0);
$total_uniform = round($totals['total_uniform'] ?? 0, 0);
$total_net_pay = round($totals['total_net_pay'] ?? 0, 0);
$total_extra_days_salary = round($totals['total_extra_days_salary'] ?? 0, 0);
$total_extra_days = round($totals['total_extra_days'] ?? 0, 0);
$total_leave_full_days = round($totals['total_leave_full_days'] ?? 0, 0);
$total_leave_half_days = round($totals['total_leave_half_days'] ?? 0, 0);

// Main query with pagination
$query = "SELECT e.id AS employee_id, s.id AS salary_id, e.name, s.month_year, s.total_salary, s.extra_days, s.extra, s.bonus, 
          s.leave_full_days, s.leave_half_days, s.pf, s.late_charge, s.deposit, s.withdrawal, s.uniform, s.professional_tax, 
          e.payment_type, e.bank_name, s.gross_salary, s.net_pay 
          FROM employees e 
          JOIN salaries s ON e.id = s.employee_id";
if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}
$query .= " ORDER BY s.net_pay " . ($sort_order === 'asc' ? 'ASC' : 'DESC') . " LIMIT ?, ?";
$params[] = $offset;
$params[] = $salaries_per_page;
$types .= "ii";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Fetch data into an array
$data_rows = [];
while ($row = $result->fetch_assoc()) {
    $basic_salary = (int)round($row['total_salary'] ?? 0, 0);
    $daily_rate = $basic_salary / 30;
    $extra_days = $row['extra_days'] ?? 0;
    $extra = (int)round($row['extra'] ?? 0, 0);
    $bonus = (int)round($row['bonus'] ?? 0, 0);
    $leave_full_days = $row['leave_full_days'] ?? 0;
    $leave_half_days = $row['leave_half_days'] ?? 0;
    $late_charge = (int)round($row['late_charge'] ?? 0, 0);
    $deposit = (int)round($row['deposit'] ?? 0, 0);
    $withdrawal = (int)round($row['withdrawal'] ?? 0, 0);
    $uniform = (int)round($row['uniform'] ?? 0, 0);
    $pf = (int)round($row['pf'] ?? 0, 0);
    $professional_tax = (int)round($row['professional_tax'] ?? 0, 0);
    $gross_salary = (int)round($row['gross_salary'] ?? 0, 0);
    $net_pay = (int)round($row['net_pay'] ?? 0, 0);

    $extra_days_salary = (int)round($daily_rate * $extra_days, 0);
    $leave_deduction = (int)round(($leave_full_days + $leave_half_days * 0.5) * $daily_rate, 0);

    $display_payment_type = $row['payment_type'] === 'cash' ? 'Cash' : ($row['bank_name'] ? $row['bank_name'] . ' Bank' : 'Bank');

    $data_rows[] = [
        'employee_id' => $row['employee_id'],
        'salary_id' => $row['salary_id'],
        'name' => $row['name'],
        'month_year' => $row['month_year'],
        'basic_salary' => $basic_salary,
        'extra_days' => $extra_days,
        'extra_days_salary' => $extra_days_salary,
        'extra' => $extra,
        'bonus' => $bonus,
        'leave_full_days' => $leave_full_days,
        'leave_half_days' => $leave_half_days,
        'leave_deduction' => $leave_deduction,
        'gross_salary' => $gross_salary,
        'pf' => $pf,
        'professional_tax' => $professional_tax,
        'late_charge' => $late_charge,
        'deposit' => $deposit,
        'withdrawal' => $withdrawal,
        'uniform' => $uniform,
        'net_pay' => $net_pay,
        'payment_type' => $display_payment_type
    ];
}
?>

<div class="row mb-4">
    <div class="col-md-10 mx-auto">
        <div class="card p-3 shadow-sm">
            <form method="POST" id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label for="month_year" class="form-label">Filter by Month & Year:</label>
                    <input type="month" id="month_year" name="month_year" class="form-control" value="<?php echo htmlspecialchars($month_year); ?>">
                </div>
                <div class="col-md-3">
                    <label for="search" class="form-label">Search by Name:</label>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Enter name" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                
                <div class="col-md-3">
                    <label for="filter_type" class="form-label">Filter by Type:</label>
                    <select id="filter_type" name="filter_type" class="form-select">
                        <option value="all" <?php echo $filter_type === 'all' ? 'selected' : ''; ?>>All</option>
                        <option value="Cash" <?php echo $filter_type === 'Cash' ? 'selected' : ''; ?>>Cash</option>
                        <option value="HDFC Bank" <?php echo $filter_type === 'HDFC Bank' ? 'selected' : ''; ?>>HDFC Bank</option>
                        <option value="Apprentice" <?php echo $filter_type === 'Apprentice' ? 'selected' : ''; ?>>Apprentice</option>
                        <option value="Other Bank" <?php echo $filter_type === 'Other Bank' ? 'selected' : ''; ?>>Other Bank</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="sort_order" class="form-label">Sort by Salary:</label>
                    <select id="sort_order" name="sort_order" class="form-select">
                        <option value="desc" <?php echo $sort_order === 'desc' ? 'selected' : ''; ?>>High to Low</option>
                        <option value="asc" <?php echo $sort_order === 'asc' ? 'selected' : ''; ?>>Low to High</option>
                    </select>
                </div>
                <div class="col-md-12 text-end">
                    <button type="submit" name="export_excel" class="btn btn-success mt-2">Export to Excel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card p-4">
            <h3 class="text-center mb-4">Employee Salaries</h3>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>SR</th>
                            <th>Name</th>
                            <th>Month-Year</th>
                            <th>Basic Salary</th>
                            <th>Extra Days</th>
                            <th>Extra Days Salary (₹)</th>
                            <th>Extra</th>
                            <th>Bonus</th>
                            <th>Leave Full Days</th>
                            <th>Leave Half Days</th>
                            <th>Leave Deduction</th>
                            <th>Gross Salary</th>
                            <th>Less: Provident Fund</th>
                            <th>Less: Professional Tax</th>
                            <th>Less: Late Charge</th>
                            <th>Less: Deposit</th>
                            <th>Less: Withdrawal</th>
                            <th>Less: Uniform</th>
                            <th>Net Salary</th>
                            <th>Payment Type</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sr = $offset + 1;
                        foreach ($data_rows as $row) { 
                        ?>
                            <tr>
                                <td><?php echo $sr++; ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['month_year']); ?></td>
                                <td><?php echo "₹" . number_format($row['basic_salary'], 0); ?></td>
                                <td><?php echo $row['extra_days'] ? (int)$row['extra_days'] : '-'; ?></td>
                                <td><?php echo $row['extra_days_salary'] ? "₹" . number_format($row['extra_days_salary'], 0) : '-'; ?></td>
                                <td><?php echo $row['extra'] ? "₹" . number_format($row['extra'], 0) : '-'; ?></td>
                                <td><?php echo $row['bonus'] ? "₹" . number_format($row['bonus'], 0) : '-'; ?></td>
                                <td><?php echo $row['leave_full_days'] ? (int)$row['leave_full_days'] : '-'; ?></td>
                                <td><?php echo $row['leave_half_days'] ? (int)$row['leave_half_days'] : '-'; ?></td>
                                <td><?php echo $row['leave_deduction'] ? "₹" . number_format($row['leave_deduction'], 0) : '-'; ?></td>
                                <td><?php echo "₹" . number_format($row['gross_salary'], 0); ?></td>
                                <td><?php echo $row['pf'] ? "₹" . number_format($row['pf'], 0) : '-'; ?></td>
                                <td><?php echo $row['professional_tax'] ? "₹" . number_format($row['professional_tax'], 0) : '-'; ?></td>
                                <td><?php echo $row['late_charge'] ? "₹" . number_format($row['late_charge'], 0) : '-'; ?></td>
                                <td><?php echo $row['deposit'] ? "₹" . number_format($row['deposit'], 0) : '-'; ?></td>
                                <td><?php echo $row['withdrawal'] ? "₹" . number_format($row['withdrawal'], 0) : '-'; ?></td>
                                <td><?php echo $row['uniform'] ? "₹" . number_format($row['uniform'], 0) : '-'; ?></td>
                                <td><?php echo "₹" . number_format($row['net_pay'], 0); ?></td>
                                <td><?php echo htmlspecialchars($row['payment_type']); ?></td>
                                <td>
                                    <a href="edit_salary.php?id=<?php echo $row['salary_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="delete_salary.php?id=<?php echo $row['salary_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this salary record?');">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr class="table-info">
                            <td colspan="3" class="text-end"><strong>Total:</strong></td>
                            <td><strong><?php echo "₹" . number_format($total_basic_salary, 0); ?></strong></td>
                            <td><strong><?php echo $total_extra_days; ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_extra_days_salary, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_extra, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_bonus, 0); ?></strong></td>
                            <td><strong><?php echo $total_leave_full_days; ?></strong></td>
                            <td><strong><?php echo $total_leave_half_days; ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_leave_deduction, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_gross_salary, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_pf, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_professional_tax, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_late_charge, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_deposit, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_withdrawal, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_uniform, 0); ?></strong></td>
                            <td><strong><?php echo "₹" . number_format($total_net_pay, 0); ?></strong></td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1) { ?>
            <nav aria-label="Salary list pagination" class="mt-4">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="#" onclick="<?php echo $page > 1 ? 'preserveFilters(' . ($page - 1) . ')' : 'return false'; ?>">Previous</a>
                    </li>
                    <?php
                    $range = 2;
                    $start = max(1, $page - $range);
                    $end = min($total_pages, $page + $range);

                    if ($start > 2) {
                        echo '<li class="page-item"><a class="page-link" href="#" onclick="preserveFilters(1)">1</a></li>';
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }

                    for ($i = $start; $i <= $end; $i++) {
                        echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
                        echo '<a class="page-link" href="#" onclick="preserveFilters(' . $i . ')">' . $i . '</a>';
                        echo '</li>';
                    }

                    if ($end < $total_pages - 1) {
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        echo '<li class="page-item"><a class="page-link" href="#" onclick="preserveFilters(' . $total_pages . ')">' . $total_pages . '</a></li>';
                    }
                    ?>
                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="#" onclick="<?php echo $page < $total_pages ? 'preserveFilters(' . ($page + 1) . ')' : 'return false'; ?>">Next</a>
                    </li>
                </ul>
            </nav>
            <?php } ?>
        </div>
    </div>
</div>

<style>
.table-responsive {
    position: relative;
    overflow-x: auto;
    max-height: 500px;
}

.table thead th {
    position: sticky;
    top: 0;
    background-color: #34495e;
    z-index: 2;
    box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('filterForm');
    const monthYearInput = document.getElementById('month_year');
    const searchInput = document.getElementById('search');
    const sortOrderInput = document.getElementById('sort_order');
    const filterTypeInput = document.getElementById('filter_type');

    let debounceTimeout;
    function submitForm() {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            const url = new URL(window.location.href);
            url.searchParams.set('month_year', monthYearInput.value);
            url.searchParams.set('search', searchInput.value);
            url.searchParams.set('sort_order', sortOrderInput.value);
            url.searchParams.set('filter_type', filterTypeInput.value);
            url.searchParams.set('page', 1);
            window.history.pushState({}, '', url);
            form.submit();
        }, 300);
    }

    monthYearInput.addEventListener('change', function() {
        if (monthYearInput.value) {
            submitForm();
        }
    });
    searchInput.addEventListener('input', submitForm);
    sortOrderInput.addEventListener('change', submitForm);
    filterTypeInput.addEventListener('change', submitForm);

    const currentSearchValue = searchInput.value;
    if (currentSearchValue) {
        searchInput.focus();
        searchInput.setSelectionRange(currentSearchValue.length, currentSearchValue.length);
    }

    window.preserveFilters = function(page) {
        const url = new URL(window.location.href);
        url.searchParams.set('page', page);
        url.searchParams.set('month_year', monthYearInput.value);
        url.searchParams.set('search', searchInput.value);
        url.searchParams.set('sort_order', sortOrderInput.value);
        url.searchParams.set('filter_type', filterTypeInput.value);
        window.history.pushState({}, '', url);

        const hiddenPage = document.createElement('input');
        hiddenPage.type = 'hidden';
        hiddenPage.name = 'page';
        hiddenPage.value = page;
        form.appendChild(hiddenPage);

        const hiddenMonthYear = document.createElement('input');
        hiddenMonthYear.type = 'hidden';
        hiddenMonthYear.name = 'month_year';
        hiddenMonthYear.value = monthYearInput.value;
        form.appendChild(hiddenMonthYear);

        const hiddenSearch = document.createElement('input');
        hiddenSearch.type = 'hidden';
        hiddenSearch.name = 'search';
        hiddenSearch.value = searchInput.value;
        form.appendChild(hiddenSearch);

        const hiddenSortOrder = document.createElement('input');
        hiddenSortOrder.type = 'hidden';
        hiddenSortOrder.name = 'sort_order';
        hiddenSortOrder.value = sortOrderInput.value;
        form.appendChild(hiddenSortOrder);

        const hiddenFilterType = document.createElement('input');
        hiddenFilterType.type = 'hidden';
        hiddenFilterType.name = 'filter_type';
        hiddenFilterType.value = filterTypeInput.value;
        form.appendChild(hiddenFilterType);

        form.submit();
    }
});
</script>

<?php
$stmt->close();
$total_stmt->close();
$count_stmt->close();
include 'footer.php';
?>