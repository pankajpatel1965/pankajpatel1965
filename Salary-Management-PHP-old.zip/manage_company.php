<?php
include 'db_connect.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}
// Fetch the company details (only one record should exist)
$company = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM company_details LIMIT 1"));

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_company'])) {
    $company_name = $_POST['company_name'];
    $branch_code = $_POST['branch_code'];
    $sender = $_POST['sender'];
    $remitter_account_no = $_POST['remitter_account_no'];
    $remitter_name = $_POST['remitter_name'];
    $debit_account = $_POST['debit_account'];
    $beneficiary_account_type = $_POST['beneficiary_account_type'];
    $remittance_details = $_POST['remittance_details'];
    $debit_account_system = $_POST['debit_account_system'];
    $originator_of_remittance = $_POST['originator_of_remittance'];
    $address = $_POST['address'];

    if ($company) {
        // Update existing company
        $sql = "UPDATE company_details SET 
                company_name = ?, 
                branch_code = ?, 
                sender = ?, 
                remitter_account_no = ?, 
                remitter_name = ?, 
                debit_account = ?, 
                beneficiary_account_type = ?, 
                remittance_details = ?, 
                debit_account_system = ?, 
                originator_of_remittance = ?, 
                address = ?
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssssssi", $company_name, $branch_code, $sender, $remitter_account_no, $remitter_name, $debit_account, $beneficiary_account_type, $remittance_details, $debit_account_system, $originator_of_remittance, $address, $company['id']);
    } else {
        // Insert new company (should only happen once)
        $sql = "INSERT INTO company_details (company_name, branch_code, sender, remitter_account_no, remitter_name, debit_account, beneficiary_account_type, remittance_details, debit_account_system, originator_of_remittance, address) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssssss", $company_name, $branch_code, $sender, $remitter_account_no, $remitter_name, $debit_account, $beneficiary_account_type, $remittance_details, $debit_account_system, $originator_of_remittance, $address);
    }

    if ($stmt->execute()) {
        header("Location: manage_company.php");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
    $stmt->close();
}

$page_title = "Manage Company";
include 'header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card p-4">
            <h3 class="text-center mb-4"><?php echo $company ? 'Update Company' : 'Add Company'; ?></h3>
            <?php if (isset($error)) { echo "<p class='text-danger text-center mb-3'>$error</p>"; } ?>
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="company_name" class="form-label">Company Name:</label>
                        <input type="text" id="company_name" name="company_name" class="form-control" value="<?php echo $company ? htmlspecialchars($company['company_name']) : ''; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="branch_code" class="form-label">Branch Code:</label>
                        <input type="text" id="branch_code" name="branch_code" class="form-control" value="<?php echo $company ? htmlspecialchars($company['branch_code']) : ''; ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="sender" class="form-label">Sender:</label>
                        <input type="text" id="sender" name="sender" class="form-control" value="<?php echo $company ? htmlspecialchars($company['sender']) : ''; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="remitter_account_no" class="form-label">Remitter Account No:</label>
                        <input type="text" id="remitter_account_no" name="remitter_account_no" class="form-control" value="<?php echo $company ? htmlspecialchars($company['remitter_account_no']) : ''; ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="remitter_name" class="form-label">Remitter Name:</label>
                        <input type="text" id="remitter_name" name="remitter_name" class="form-control" value="<?php echo $company ? htmlspecialchars($company['remitter_name']) : ''; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="debit_account" class="form-label">Debit Account:</label>
                        <input type="text" id="debit_account" name="debit_account" class="form-control" value="<?php echo $company ? htmlspecialchars($company['debit_account']) : ''; ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="beneficiary_account_type" class="form-label">Beneficiary Account Type:</label>
                        <input type="text" id="beneficiary_account_type" name="beneficiary_account_type" class="form-control" value="<?php echo $company ? htmlspecialchars($company['beneficiary_account_type']) : ''; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="remittance_details" class="form-label">Remittance Details:</label>
                        <textarea id="remittance_details" name="remittance_details" class="form-control" required><?php echo $company ? htmlspecialchars($company['remittance_details']) : ''; ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="debit_account_system" class="form-label">Debit Account System:</label>
                        <input type="text" id="debit_account_system" name="debit_account_system" class="form-control" value="<?php echo $company ? htmlspecialchars($company['debit_account_system']) : ''; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="originator_of_remittance" class="form-label">Originator of Remittance:</label>
                        <input type="text" id="originator_of_remittance" name="originator_of_remittance" class="form-control" value="<?php echo $company ? htmlspecialchars($company['originator_of_remittance']) : ''; ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="address" class="form-label">Company Address:</label>
                        <textarea id="address" name="address" class="form-control" rows="3" required><?php echo $company ? htmlspecialchars($company['address']) : ''; ?></textarea>
                    </div>
                </div>
                <button type="submit" name="update_company" class="btn btn-primary w-100"><?php echo $company ? 'Update Company' : 'Add Company'; ?></button>
                <a href="index.php" class="btn btn-secondary w-100 mt-3">Back to Dashboard</a>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>